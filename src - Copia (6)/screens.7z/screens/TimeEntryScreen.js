import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Modal
} from 'react-native';

// Array dei mesi in italiano per visualizzazione
const mesiItaliani = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 
                      'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useWorkEntries, useSettings } from '../hooks';
import { formatDate, formatTime, formatCurrency, getDayName } from '../utils';
import { createWorkEntryFromData, getSafeSettings, calculateItemBreakdown, formatSafeHours } from '../utils/earningsHelper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import { Picker } from '@react-native-picker/picker';
import DatabaseService from '../services/DatabaseService';
import CalculationService from '../services/CalculationService';

const TimeEntryScreen = ({ navigation, route }) => {
  const currentDate = new Date();
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth() + 1);
  const [showFeriePermesso, setShowFeriePermesso] = useState(false);
  const [standbyConfirmations, setStandbyConfirmations] = useState({});
  const [editingDayTypeId, setEditingDayTypeId] = useState(null);
  const [editingDayTypeValue, setEditingDayTypeValue] = useState('');
  const [dayTypeModalVisible, setDayTypeModalVisible] = useState(false);
  const [selectedDayTypeEntry, setSelectedDayTypeEntry] = useState(null);
  const [selectedDayTypeValue, setSelectedDayTypeValue] = useState('');
  
  // Mostra sempre tutti gli inserimenti di tutti i mesi
  const { entries, isLoading, refreshEntries } = useWorkEntries(selectedYear, selectedMonth, true);
  
  // Log per debug
  useEffect(() => {
    console.log(`TimeEntryScreen: Caricati ${entries?.length || 0} inserimenti`);
    if (entries && entries.length > 0) {
      // Log date range
      const dates = entries.map(e => new Date(e.date));
      const minDate = new Date(Math.min.apply(null, dates)).toISOString().split('T')[0];
      const maxDate = new Date(Math.max.apply(null, dates)).toISOString().split('T')[0];
      console.log(`TimeEntryScreen: Range date da ${minDate} a ${maxDate}`);
    }
  }, [entries]);
  
  const { settings } = useSettings();
  const contract = settings.contract || {};
  const monthlySalary = contract.monthlySalary || 0;
  const dailyRate = monthlySalary / 26;
  const officialHourlyRate = monthlySalary / 173;
  const overtimeDay = officialHourlyRate * 1.20;
  const overtimeNightUntil22 = officialHourlyRate * 1.25;
  const overtimeNightAfter22 = officialHourlyRate * 1.35;

  useEffect(() => {
    // Carica stato conferma per tutte le entry del mese
    const loadConfirmations = async () => {
      const confirmations = {};
      for (const entry of entries) {
        if (entry.is_standby_day === 1) {
          const key = `standby_confirmed_${entry.date}`;
          const value = await AsyncStorage.getItem(key);
          confirmations[entry.date] = value === 'true';
        }
      }
      setStandbyConfirmations(confirmations);
    };
    if (entries.length > 0) loadConfirmations();
  }, [entries]);

  // Aggiorna la lista ogni volta che la schermata torna in primo piano
  useFocusEffect(
    React.useCallback(() => {
      refreshEntries();
    }, [selectedYear, selectedMonth])
  );

  useEffect(() => {
    if (route && route.params && route.params.refresh) {
      refreshEntries();
      // Reset param per evitare loop
      navigation.setParams({ refresh: false });
    }
  }, [route?.params?.refresh]);

  const handleNewEntry = () => {
    navigation.navigate('TimeEntryForm', { ferie: false, permesso: false });
  };
  
  // Aggiorna la dashboard dopo ogni salvataggio
  useEffect(() => {
    if (route && route.params && route.params.refreshDashboard) {
      // Imposta il flag per il refresh della Dashboard
      const setDashboardRefreshFlag = async () => {
        try {
          await AsyncStorage.setItem('dashboard_needs_refresh', 'true');
        } catch (e) {
          // Ignora errori AsyncStorage
        }
      };
      setDashboardRefreshFlag();
      navigation.setParams({ refreshDashboard: false });
    }
  }, [route?.params?.refreshDashboard]);

  const handleEditEntry = (entry) => {
    navigation.navigate('TimeEntryForm', {
      entry,
      isEdit: true,
      ferie: entry.ferie,
      permesso: entry.permesso,
      enableDelete: true // Passa flag per abilitare cancellazione
    });
  };

  const dayTypeLabels = {
    lavorativa: { label: 'Lavoro', color: '#2196F3' },
    ferie: { label: 'Ferie', color: '#43a047' },
    permesso: { label: 'Permesso', color: '#ef6c00' },
    malattia: { label: 'Malattia', color: '#d32f2f' },
    riposo: { label: 'Riposo compensativo', color: '#757575' },
  };
  
  const dayTypeIcons = {
    lavorativa: { icon: 'briefcase', color: '#2196F3' },
    ferie: { icon: 'sunny', color: '#43a047' },
    permesso: { icon: 'person', color: '#ef6c00' },
    malattia: { icon: 'medical', color: '#d32f2f' },
    riposo: { icon: 'bed', color: '#757575' },
  };

  const openDayTypeModal = (entry) => {
    setSelectedDayTypeEntry(entry);
    setSelectedDayTypeValue(entry.day_type || entry.dayType || 'lavorativa');
    setDayTypeModalVisible(true);
  };

  const closeDayTypeModal = () => {
    setDayTypeModalVisible(false);
    setSelectedDayTypeEntry(null);
  };

  const confirmDayTypeChange = async () => {
    if (!selectedDayTypeEntry) return;
    try {
      await DatabaseService.updateWorkEntry({ ...selectedDayTypeEntry, day_type: selectedDayTypeValue });
      closeDayTypeModal();
      refreshEntries();
    } catch (e) {
      Alert.alert('Errore', 'Impossibile aggiornare il tipo giornata.');
    }
  };
  
  // Determina il nome del mese dall'entry
  const getMonthLabel = (dateString) => {
    const entryDate = new Date(dateString);
    const monthNames = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 
                        'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
    return `${monthNames[entryDate.getMonth()]} ${entryDate.getFullYear()}`;
  };

  const renderWorkEntry = ({ item }) => {
    const entryDate = new Date(item.date);
    const dayName = getDayName(item.date);
    const workHours = calculateTotalHours(item);
    
    // Determina se l'inserimento è del mese corrente o precedente
    const entryMonth = entryDate.getMonth() + 1;
    const entryYear = entryDate.getFullYear();
    const isPreviousMonth = (entryYear !== selectedYear || entryMonth !== selectedMonth);

    const note = item.note;
    const isStandbyConfirmed = standbyConfirmations[item.date];

    // Usa le funzioni helper per calcolare il breakdown come nel form
    const safeSettings = getSafeSettings(settings);
    const breakdown = calculateItemBreakdown(item, settings);
    
    // Assicuriamoci che il total sia impostato correttamente
    if (item.total_earnings && (!breakdown.total || breakdown.total === 0)) {
      breakdown.total = parseFloat(item.total_earnings);
    }
    
    // Estrai i valori dal breakdown calcolato
    const regularPay = breakdown.ordinary?.total || 0;
    const regularHours = (breakdown.ordinary?.hours?.lavoro_giornaliera || 0) + (breakdown.ordinary?.hours?.viaggio_giornaliera || 0);
    const overtimeHours = (breakdown.ordinary?.hours?.lavoro_extra || 0) + (breakdown.ordinary?.hours?.viaggio_extra || 0);
    const overtimePay = (breakdown.ordinary?.earnings?.lavoro_extra || 0) + (breakdown.ordinary?.earnings?.viaggio_extra || 0);
    const travelPay = breakdown.ordinary?.earnings?.viaggio_extra || 0;
    const travelAllowance = breakdown.allowances?.travel || 0;
    const standbyAllowance = breakdown.allowances?.standby || 0;
    const standbyWorkPay = breakdown.standby?.workEarnings?.total || 0;
    const standbyTravelPay = breakdown.standby?.travelEarnings?.total || 0;
    const baseRate = safeSettings.contract?.hourlyRate || 16.41;
    
    // Verifica se ci sono ore ordinarie o di reperibilità
    const hasOrdinaryHours = breakdown.ordinary?.hours && 
      (breakdown.ordinary.hours.lavoro_giornaliera > 0 || 
       breakdown.ordinary.hours.viaggio_giornaliera > 0 || 
       breakdown.ordinary.hours.lavoro_extra > 0 || 
       breakdown.ordinary.hours.viaggio_extra > 0);
       
    const hasStandbyHours = breakdown.standby?.workHours && 
      (Object.values(breakdown.standby.workHours).some(h => h > 0) || 
       Object.values(breakdown.standby.travelHours).some(h => h > 0));
       
    const hasAllowances = breakdown.allowances && 
      (breakdown.allowances.travel > 0 || 
       breakdown.allowances.meal > 0 || 
       breakdown.allowances.standby > 0);
    
    const dayType = item.day_type || item.dayType || 'lavorativa';
    const dayTypeInfo = dayTypeLabels[dayType] || dayTypeLabels.lavorativa;

    // Helper per formattare i calcoli delle tariffe
    const formatRateCalc = (hours, rate, total) => {
      if (hours <= 0) return null;
      return `${rate.toFixed(2).replace('.', ',')} € × ${formatSafeHours(hours)} = ${total.toFixed(2).replace('.', ',')} €`;
    };
    
    return (
      <TouchableOpacity 
        style={[styles.entryCard, {
          borderLeftWidth: 4, 
          borderLeftColor: item.is_standby_day === 1 ? '#9C27B0' : '#2196F3',
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 4,
          backgroundColor: isPreviousMonth ? '#fafafa' : '#ffffff', // Background più chiaro per mese precedente
          borderStyle: isPreviousMonth ? 'dashed' : 'solid',
          borderColor: isPreviousMonth ? '#e0e0e0' : '#d0d0d0',
        }]}
        onPress={() => handleEditEntry(item)}
        onLongPress={() => saveEntry(item)}
      >
        {/* Header con data, tipo giornata e guadagni */}
        <View style={{
          borderBottomWidth: 1,
          borderBottomColor: '#e0e0e0',
          marginBottom: 12,
          paddingBottom: 8
        }}>
          {/* Prima riga: data e guadagno */}
          <View style={{flexDirection:'row', alignItems:'center', justifyContent:'space-between'}}>
            <View style={{flexDirection:'row', alignItems:'center', flex:1}}>
              {/* Data e giorno settimana */}
              <View style={{flexDirection: 'column'}}>
                <View style={[styles.dateContainer, {
                  backgroundColor: dayTypeInfo.color + '22', // Colore sfumato in base al tipo giornata
                  borderRadius: 8,
                  padding: 8
                }]}>
                  <Text style={[styles.entryDate, {color: dayTypeInfo.color}]}>{formatDate(item.date, 'dd/MM')}</Text>
                  <Text style={[styles.entryDay, {fontWeight: '600'}]}>{dayName}</Text>
                </View>
                {isPreviousMonth && (
                  <View style={{
                    backgroundColor: '#ffebee',
                    paddingVertical: 2,
                    paddingHorizontal: 6,
                    borderRadius: 10,
                    marginTop: 4,
                    alignSelf: 'center'
                  }}>
                    <Text style={{color: '#c62828', fontSize: 10, fontWeight: 'bold'}}>MESE PREC</Text>
                  </View>
                )}
              </View>
              
              {/* Tipo giornata dropdown */}
              <View style={{marginLeft:12, minWidth:130}}>
                <Text style={{fontSize: 12, color: '#555', marginBottom: 2}}>Tipo giornata:</Text>
                <Picker
                  selectedValue={dayType}
                  onValueChange={(value) => handleDayTypeChange(item, value)}
                  style={{
                    height: 36, 
                    width: 130, 
                    color: dayTypeLabels[dayType]?.color || '#333', 
                    fontWeight: 'bold'
                  }}>
                  {Object.entries(dayTypeLabels).map(([key, val]) => (
                    <Picker.Item key={key} label={val.label} value={key} color={val.color} />
                  ))}
                </Picker>
              </View>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const calculateTotalHours = (entry) => {
    let totalMinutes = 0;
    
    // Calculate work hours
    if (entry.work_start_1 && entry.work_end_1) {
      totalMinutes += calculateTimeDiff(entry.work_start_1, entry.work_end_1);
    }
    if (entry.work_start_2 && entry.work_end_2) {
      totalMinutes += calculateTimeDiff(entry.work_start_2, entry.work_end_2);
    }
    
    // Calculate travel hours
    if (entry.departure_company && entry.arrival_site) {
      totalMinutes += calculateTimeDiff(entry.departure_company, entry.arrival_site);
    }
    if (entry.departure_return && entry.arrival_company) {
      totalMinutes += calculateTimeDiff(entry.departure_return, entry.arrival_company);
    }

    // Aggiungi ore da interventi di reperibilità
    if (entry.interventi && Array.isArray(entry.interventi)) {
      entry.interventi.forEach(intervento => {
        if (intervento.work_start_1 && intervento.work_end_1) {
          totalMinutes += calculateTimeDiff(intervento.work_start_1, intervento.work_end_1);
        }
        if (intervento.work_start_2 && intervento.work_end_2) {
          totalMinutes += calculateTimeDiff(intervento.work_start_2, intervento.work_end_2);
        }
        if (intervento.departure_company && intervento.arrival_site) {
          totalMinutes += calculateTimeDiff(intervento.departure_company, intervento.arrival_site);
        }
        if (intervento.departure_return && intervento.arrival_company) {
          totalMinutes += calculateTimeDiff(intervento.departure_return, intervento.arrival_company);
        }
      });
    }
    
    return totalMinutes / 60;
  };

  const calculateTimeDiff = (startTime, endTime) => {
    if (!startTime || !endTime) return 0;
    
    const [startHours, startMinutes] = startTime.split(':').map(Number);
    const [endHours, endMinutes] = endTime.split(':').map(Number);
    
    const startTotalMinutes = startHours * 60 + startMinutes;
    let endTotalMinutes = endHours * 60 + endMinutes;
    
    // Handle overnight work
    if (endTotalMinutes < startTotalMinutes) {
      endTotalMinutes += 24 * 60;
    }
    
    return endTotalMinutes - startTotalMinutes;
  };

  // Salvataggio reale entry su DatabaseService (SQLite)
  const saveEntry = async (entry) => {
    try {
      // Mappa i campi per compatibilità DB
      const dbEntry = {
        ...entry,
        siteName: entry.site_name || entry.siteName || '',
        vehicleDriven: entry.vehicle_driven || entry.vehicleDriven || '',
      };
      await DatabaseService.insertWorkEntry(dbEntry);
      Alert.alert('Salvataggio','Inserimento salvato su database!');
      refreshEntries();
    } catch (e) {
      Alert.alert('Errore','Errore durante il salvataggio su database.');
    }
  };

  const handleDayTypeChange = async (entry, newDayType) => {
    try {
      // Crea un work entry aggiornato con il nuovo tipo giornata
      const updatedEntry = { ...entry, day_type: newDayType };
      
      // Ricalcola il totale degli earnings usando lo stesso servizio di calcolo
      const safeSettings = getSafeSettings(settings);
      const breakdown = calculateItemBreakdown(updatedEntry, settings);
      
      // Assicuriamoci che il breakdown.total esista, altrimenti utilizziamo 0
      const totalEarnings = breakdown.total || 0;
      console.log(`Nuovo totale guadagni per ${updatedEntry.date}: ${totalEarnings}`);
      
      // Aggiorna l'entry includendo il totale ricalcolato
      await DatabaseService.updateWorkEntry({ 
        ...updatedEntry, 
        total_earnings: totalEarnings
      });
      
      // Ricarica gli inserimenti per mostrare i totali aggiornati
      refreshEntries();
    } catch (e) {
      console.error('Errore aggiornamento tipo giornata:', e);
      Alert.alert('Errore', 'Impossibile aggiornare il tipo giornata.');
    }
  };

  if (isLoading && entries.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#2196F3" />
          <Text style={styles.loadingText}>Caricamento inserimenti...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header rivisto con solo pulsante nuovo inserimento più visibile */}
      <View style={[styles.header, { flexDirection: 'column', alignItems: 'stretch', paddingBottom: 15 }]}>
        {/* Pulsante Nuovo grande e ben visibile in alto */}
        <TouchableOpacity 
          style={{
            backgroundColor: '#1976D2',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            paddingVertical: 14,
            borderRadius: 10,
            elevation: 6,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 3 },
            shadowOpacity: 0.2,
            shadowRadius: 4,
            marginBottom: 12,
            borderWidth: 1,
            borderColor: '#1565C0',
          }} 
          onPress={handleNewEntry} 
          onLongPress={()=>Alert.alert('Nuovo inserimento','Aggiungi un nuovo inserimento orario per la giornata selezionata.')}
        >
          <Ionicons name="add-circle" size={32} color="white" />
          <Text style={{
            color: 'white',
            fontSize: 20,
            fontWeight: 'bold',
            marginLeft: 10,
            letterSpacing: 0.5
          }}>+ NUOVO INSERIMENTO</Text>
        </TouchableOpacity>

        {/* Seconda riga: solo titolo */}
        <View style={{ 
          flexDirection: 'row', 
          justifyContent: 'center', 
          alignItems: 'center', 
          marginTop: 5,
          paddingTop: 10,
          borderTopWidth: 1,
          borderTopColor: '#e0e0e0'
        }}>
          <Text style={styles.headerTitle}>Storico Inserimenti</Text>
        </View>
      </View>
      <FlatList
        data={entries}
        renderItem={renderWorkEntry}
        keyExtractor={(item) => item.id.toString()}
        style={styles.list}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={isLoading} onRefresh={refreshEntries} tintColor="#2196F3" title="Aggiornamento..." titleColor="#2196F3" />
        }
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={() => (
          <View>
            <View style={{
              flexDirection: 'row', 
              alignItems: 'center', 
              padding: 10, 
              backgroundColor: '#e3f2fd', 
              borderRadius: 8,
              marginBottom: 8
            }}>
              <Ionicons name="information-circle-outline" size={20} color="#1976d2" style={{marginRight: 8}} />
              <Text style={{color: '#1976d2', fontSize: 14}}>
                Visualizzazione completa di tutti gli inserimenti
              </Text>
            </View>
          </View>
        )}
      />
      {/* Modal selezione tipo giornata */}
      <Modal
        visible={dayTypeModalVisible}
        transparent
        animationType="slide"
        onRequestClose={closeDayTypeModal}
      >
        <View style={{flex:1,backgroundColor:'rgba(0,0,0,0.3)',justifyContent:'center',alignItems:'center'}}>
          <View style={{backgroundColor:'#fff',borderRadius:12,padding:20,minWidth:260}}>
            <Text style={{fontWeight:'bold',fontSize:17,marginBottom:10}}>Seleziona tipo giornata</Text>
            <Picker
              selectedValue={selectedDayTypeValue}
              onValueChange={setSelectedDayTypeValue}
              style={{height:40,marginBottom:10}}
            >
              {Object.entries(dayTypeLabels).map(([key, val]) => (
                <Picker.Item key={key} label={val.label} value={key} />
              ))}
            </Picker>
            <View style={{flexDirection:'row',justifyContent:'flex-end',marginTop:10}}>
              <TouchableOpacity onPress={closeDayTypeModal} style={{marginRight:16}}>
                <Text style={{color:'#757575',fontWeight:'bold'}}>Annulla</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={confirmDayTypeChange}>
                <Text style={{color:'#2196F3',fontWeight:'bold'}}>Conferma</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  header: {
    backgroundColor: 'white',
    paddingHorizontal: 16,
    paddingTop: 15,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 2
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  // Stili vecchi mantenuti per compatibilità
  addButton: {
    backgroundColor: '#2196F3',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
  },
  addButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 5,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 20,
    marginBottom: 10,
  },
  emptySubtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    lineHeight: 24,
  },
  list: {
    flex: 1,
  },
  listContent: {
    padding: 15,
  },
  entryCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  entryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  dateContainer: {
    alignItems: 'center',
    marginRight: 15,
  }
});

export default TimeEntryScreen;
