import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Modal
} from 'react-native';

// Array dei mesi in italiano per visualizzazione
const mesiItaliani = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 
                      'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useWorkEntries, useSettings } from '../hooks';
import { formatDate, formatTime, formatCurrency, getDayName } from '../utils';
import { createWorkEntryFromData, getSafeSettings, calculateItemBreakdown, formatSafeHours } from '../utils/earningsHelper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import { Picker } from '@react-native-picker/picker';
import DatabaseService from '../services/DatabaseService';
import CalculationService from '../services/CalculationService';

const TimeEntryScreen = ({ navigation, route }) => {
  const currentDate = new Date();
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth() + 1);
  const [showFeriePermesso, setShowFeriePermesso] = useState(false);
  const [standbyConfirmations, setStandbyConfirmations] = useState({});
  const [editingDayTypeId, setEditingDayTypeId] = useState(null);
  const [editingDayTypeValue, setEditingDayTypeValue] = useState('');
  const [dayTypeModalVisible, setDayTypeModalVisible] = useState(false);
  const [selectedDayTypeEntry, setSelectedDayTypeEntry] = useState(null);
  const [selectedDayTypeValue, setSelectedDayTypeValue] = useState('');
  
  // Nuovi stati per la ricerca per date
  const [searchModalVisible, setSearchModalVisible] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [filteredEntries, setFilteredEntries] = useState(null);
  const [isFiltering, setIsFiltering] = useState(false);
  
  // Mostra sempre tutti gli inserimenti di tutti i mesi
  const { entries, isLoading, refreshEntries } = useWorkEntries(selectedYear, selectedMonth, true);
  
  // Log per debug
  useEffect(() => {
    console.log(`TimeEntryScreen: Caricati ${entries?.length || 0} inserimenti`);
    if (entries && entries.length > 0) {
      // Log date range
      const dates = entries.map(e => new Date(e.date));
      const minDate = new Date(Math.min.apply(null, dates)).toISOString().split('T')[0];
      const maxDate = new Date(Math.max.apply(null, dates)).toISOString().split('T')[0];
      console.log(`TimeEntryScreen: Range date da ${minDate} a ${maxDate}`);
    }
  }, [entries]);
  
  const { settings } = useSettings();
  const contract = settings.contract || {};
  const monthlySalary = contract.monthlySalary || 0;
  const dailyRate = monthlySalary / 26;
  const officialHourlyRate = monthlySalary / 173;
  const overtimeDay = officialHourlyRate * 1.20;
  const overtimeNightUntil22 = officialHourlyRate * 1.25;
  const overtimeNightAfter22 = officialHourlyRate * 1.35;

  useEffect(() => {
    // Carica stato conferma per tutte le entry del mese
    const loadConfirmations = async () => {
      const confirmations = {};
      for (const entry of entries) {
        if (entry.is_standby_day === 1) {
          const key = `standby_confirmed_${entry.date}`;
          const value = await AsyncStorage.getItem(key);
          confirmations[entry.date] = value === 'true';
        }
      }
      setStandbyConfirmations(confirmations);
    };
    if (entries.length > 0) loadConfirmations();
  }, [entries]);

  // Aggiorna la lista ogni volta che la schermata torna in primo piano
  useFocusEffect(
    React.useCallback(() => {
      refreshEntries();
    }, [selectedYear, selectedMonth])
  );

  useEffect(() => {
    if (route && route.params && route.params.refresh) {
      refreshEntries();
      // Reset param per evitare loop
      navigation.setParams({ refresh: false });
    }
  }, [route?.params?.refresh]);

  const handleNewEntry = () => {
    navigation.navigate('TimeEntryForm', { ferie: false, permesso: false });
  };  // Aggiorna la dashboard dopo ogni salvataggio
  useEffect(() => {
    if (route && route.params && route.params.refreshDashboard) {
      // Imposta il flag per il refresh della Dashboard
      const setDashboardRefreshFlag = async () => {
        try {
          await AsyncStorage.setItem('dashboard_needs_refresh', 'true');
        } catch (e) {
          // Ignora errori AsyncStorage
        }
      };
      setDashboardRefreshFlag();
      navigation.setParams({ refreshDashboard: false });
    }
  }, [route?.params?.refreshDashboard]);

  const handleEditEntry = (entry) => {
    navigation.navigate('TimeEntryForm', {
      entry,
      isEdit: true,
      ferie: entry.ferie,
      permesso: entry.permesso,
      enableDelete: true // Passa flag per abilitare cancellazione
    });
  };

  const dayTypeLabels = {
    lavorativa: { label: 'Lavoro', color: '#2196F3' },
    ferie: { label: 'Ferie', color: '#43a047' },
    permesso: { label: 'Permesso', color: '#ef6c00' },
    malattia: { label: 'Malattia', color: '#d32f2f' },
    riposo: { label: 'Riposo compensativo', color: '#757575' },
  };
  const dayTypeIcons = {
    lavorativa: { icon: 'briefcase', color: '#2196F3' },
    ferie: { icon: 'sunny', color: '#43a047' },
    permesso: { icon: 'person', color: '#ef6c00' },
    malattia: { icon: 'medical', color: '#d32f2f' },
    riposo: { icon: 'bed', color: '#757575' },
  };

  const openDayTypeModal = (entry) => {
    setSelectedDayTypeEntry(entry);
    setSelectedDayTypeValue(entry.day_type || entry.dayType || 'lavorativa');
    setDayTypeModalVisible(true);
  };

  const closeDayTypeModal = () => {
    setDayTypeModalVisible(false);
    setSelectedDayTypeEntry(null);
  };

  const confirmDayTypeChange = async () => {
    if (!selectedDayTypeEntry) return;
    try {
      await DatabaseService.updateWorkEntry({ ...selectedDayTypeEntry, day_type: selectedDayTypeValue });
      closeDayTypeModal();
      refreshEntries();
    } catch (e) {
      Alert.alert('Errore', 'Impossibile aggiornare il tipo giornata.');
    }
  };

  // Funzione per raggruppare gli inserimenti per mese
  const renderSectionHeader = ({ section }) => (
    <View style={{
      backgroundColor: '#e0f7fa',
      paddingVertical: 8,
      paddingHorizontal: 16,
      marginVertical: 8,
      borderRadius: 8,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      elevation: 2,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.2,
      shadowRadius: 2
    }}>
      <Text style={{
        fontWeight: 'bold',
        fontSize: 16,
        color: '#00838f'
      }}>
        {section.title}
      </Text>
      <Text style={{
        fontSize: 12,
        color: '#00838f',
        backgroundColor: '#b2ebf2',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 12
      }}>
        {section.data.length} inserimenti
      </Text>
    </View>
  );
  
  // Non è più necessario organizzare gli inserimenti poiché mostriamo tutti i mesi
  // e la determinazione del mese corrente/precedente avviene nel renderWorkEntry
  
  // Determina il nome del mese dall'entry
  const getMonthLabel = (dateString) => {
    const entryDate = new Date(dateString);
    const monthNames = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 
                        'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
    return `${monthNames[entryDate.getMonth()]} ${entryDate.getFullYear()}`;
  };

  const renderWorkEntry = ({ item }) => {
    const entryDate = new Date(item.date);
    const dayName = getDayName(item.date);
    const workHours = calculateTotalHours(item);
    
    // Determina se l'inserimento è del mese corrente o precedente
    const entryMonth = entryDate.getMonth() + 1;
    const entryYear = entryDate.getFullYear();
    const isPreviousMonth = (entryYear !== selectedYear || entryMonth !== selectedMonth);

    const note = item.note;
    const isStandbyConfirmed = standbyConfirmations[item.date];

    // Usa le funzioni helper per calcolare il breakdown come nel form
    const safeSettings = getSafeSettings(settings);
    const breakdown = calculateItemBreakdown(item, settings);
    
    // Assicuriamoci che il total sia impostato correttamente
    if (item.total_earnings && (!breakdown.total || breakdown.total === 0)) {
      breakdown.total = parseFloat(item.total_earnings);
    }
    
    // Estrai i valori dal breakdown calcolato
    const regularPay = breakdown.ordinary?.total || 0;
    const regularHours = (breakdown.ordinary?.hours?.lavoro_giornaliera || 0) + (breakdown.ordinary?.hours?.viaggio_giornaliera || 0);
    const overtimeHours = (breakdown.ordinary?.hours?.lavoro_extra || 0) + (breakdown.ordinary?.hours?.viaggio_extra || 0);
    const overtimePay = (breakdown.ordinary?.earnings?.lavoro_extra || 0) + (breakdown.ordinary?.earnings?.viaggio_extra || 0);
    const travelPay = breakdown.ordinary?.earnings?.viaggio_extra || 0;
    const travelAllowance = breakdown.allowances?.travel || 0;
    const standbyAllowance = breakdown.allowances?.standby || 0;
    const standbyWorkPay = breakdown.standby?.workEarnings?.total || 0;
    const standbyTravelPay = breakdown.standby?.travelEarnings?.total || 0;
    const baseRate = safeSettings.contract?.hourlyRate || 16.41;
    
    // Verifica se ci sono ore ordinarie o di reperibilità
    const hasOrdinaryHours = breakdown.ordinary?.hours && 
      (breakdown.ordinary.hours.lavoro_giornaliera > 0 || 
       breakdown.ordinary.hours.viaggio_giornaliera > 0 || 
       breakdown.ordinary.hours.lavoro_extra > 0 || 
       breakdown.ordinary.hours.viaggio_extra > 0);
       
    const hasStandbyHours = breakdown.standby?.workHours && 
      (Object.values(breakdown.standby.workHours).some(h => h > 0) || 
       Object.values(breakdown.standby.travelHours).some(h => h > 0));
       
    const hasAllowances = breakdown.allowances && 
      (breakdown.allowances.travel > 0 || 
       breakdown.allowances.meal > 0 || 
       breakdown.allowances.standby > 0);
    
    const dayType = item.day_type || item.dayType || 'lavorativa';
    const dayTypeInfo = dayTypeLabels[dayType] || dayTypeLabels.lavorativa;

    // Helper per formattare i calcoli delle tariffe
    const formatRateCalc = (hours, rate, total) => {
      if (hours <= 0) return null;
      return `${rate.toFixed(2).replace('.', ',')} € × ${formatSafeHours(hours)} = ${total.toFixed(2).replace('.', ',')} €`;
    };
    
    return (
      <TouchableOpacity 
        style={[styles.entryCard, {
          borderLeftWidth: 4, 
          borderLeftColor: item.is_standby_day === 1 ? '#9C27B0' : '#2196F3',
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 4,
          backgroundColor: isPreviousMonth ? '#fafafa' : '#ffffff', // Background più chiaro per mese precedente
          borderStyle: isPreviousMonth ? 'dashed' : 'solid',
          borderColor: isPreviousMonth ? '#e0e0e0' : '#d0d0d0',
        }]}
        onPress={() => handleEditEntry(item)}
        onLongPress={() => saveEntry(item)}
      >
        {/* Header con data, tipo giornata e guadagni */}
        <View style={{
          borderBottomWidth: 1,
          borderBottomColor: '#e0e0e0',
          marginBottom: 12,
          paddingBottom: 8
        }}>
          {/* Prima riga: data e guadagno */}
          <View style={{flexDirection:'row', alignItems:'center', justifyContent:'space-between'}}>
            <View style={{flexDirection:'row', alignItems:'center', flex:1}}>
              {/* Data e giorno settimana */}
              <View style={{flexDirection: 'column'}}>
                <View style={[styles.dateContainer, {
                  backgroundColor: dayTypeInfo.color + '22', // Colore sfumato in base al tipo giornata
                  borderRadius: 8,
                  padding: 8
                }]}>
                  <Text style={[styles.entryDate, {color: dayTypeInfo.color}]}>{formatDate(item.date, 'dd/MM')}</Text>
                  <Text style={[styles.entryDay, {fontWeight: '600'}]}>{dayName}</Text>
                </View>
                {isPreviousMonth && (
                  <View style={{
                    backgroundColor: '#ffebee',
                    paddingVertical: 2,
                    paddingHorizontal: 6,
                    borderRadius: 10,
                    marginTop: 4,
                    alignSelf: 'center'
                  }}>
                    <Text style={{color: '#c62828', fontSize: 10, fontWeight: 'bold'}}>MESE PREC</Text>
                  </View>
                )}
              </View>
              
              {/* Tipo giornata dropdown */}
              <View style={{marginLeft:12, minWidth:130}}>
                <Text style={{fontSize: 12, color: '#555', marginBottom: 2}}>Tipo giornata:</Text>
                <Picker
                  selectedValue={dayType}
                  onValueChange={(value) => handleDayTypeChange(item, value)}
                  style={{
                    height: 36, 
                    width: 130, 
                    color: dayTypeLabels[dayType]?.color || '#333', 
                    fontWeight: 'bold'
                  }}>
                  {Object.entries(dayTypeLabels).map(([key, val]) => (
                    <Picker.Item key={key} label={val.label} value={key} color={val.color} />
                  ))}
                </Picker>
              </View>
            </View>
            
            {/* Importo guadagno */}
            <View style={styles.entryEarnings}>
              {/* Se NON lavorativa, mostra solo la retribuzione giornaliera */}
              {dayType !== 'lavorativa' ? (
                <View style={{alignItems: 'flex-end'}}>
                  <Text style={{fontSize: 12, color: '#555', marginBottom: 2}}>Retribuzione giornaliera:</Text>
                  <Text style={styles.earningsAmount}>{formatCurrency(dailyRate)}</Text>
                </View>
              ) : workHours < 8 ? (
                <View style={{alignItems: 'flex-end'}}>
                  <Text style={{
                    fontSize: 11,
                    color: '#d32f2f',
                    backgroundColor: '#ffebee',
                    padding: 4,
                    borderRadius: 4,
                    marginBottom: 4
                  }}>
                    Ore {'<'} 8 - completamento necessario
                  </Text>
                  <Text style={styles.earningsAmount}>{formatCurrency(breakdown.total || 0)}</Text>
                </View>
              ) : (
                <View style={{alignItems: 'flex-end'}}>
                  <Text style={{fontSize: 12, color: '#555', marginBottom: 2}}>Totale guadagni:</Text>
                  <Text style={styles.earningsAmount}>{formatCurrency(breakdown.total || 0)}</Text>
                </View>
              )}
              
              {/* Badge reperibilità */}
              {item.is_standby_day === 1 && (
                <View style={{flexDirection: 'row', alignItems: 'center', marginTop: 4, gap: 4}}>
                  <View style={[styles.standbyBadge, {
                    width: 24,
                    height: 24,
                    borderRadius: 12
                  }]}>
                    <Text style={[styles.standbyText, {fontSize: 14}]}>R</Text>
                  </View>
                  <TouchableOpacity 
                    onPress={() => Alert.alert('Reperibilità','Badge R = Giorno di reperibilità. Il check indica conferma ricevuta.')}
                    style={[styles.standbyConfirmBadge, {
                      backgroundColor: isStandbyConfirmed ? '#4CAF50' : '#BDBDBD',
                      width: 22,
                      height: 22,
                      borderRadius: 11
                    }]}>
                    <Ionicons name={isStandbyConfirmed ? 'checkmark' : 'help'} size={14} color="white" />
                  </TouchableOpacity>
                </View>
              )}
            </View>
          </View>
          
          {/* Badge tipo giornata */}
          <View style={{flexDirection: 'row', alignItems: 'center', marginTop: 8}}>
            <View style={{
              backgroundColor: dayTypeInfo.color,
              borderRadius: 16,
              paddingHorizontal: 12,
              paddingVertical: 6,
              flexDirection: 'row',
              alignItems: 'center',
              alignSelf: 'flex-start',
              elevation: 2,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 1 },
              shadowOpacity: 0.2,
              shadowRadius: 1
            }}>
              <Ionicons name={dayTypeIcons[dayType].icon} size={16} color="#fff" style={{marginRight: 6}} />
              <Text style={{
                color: '#fff',
                fontWeight: 'bold',
                fontSize: 13
              }}>
                {dayTypeInfo.label}
              </Text>
            </View>
          </View>
        </View>
        {/* Orari giornata standard - con design migliorato */}
        <View style={[styles.entryTimes, {
          backgroundColor: '#f5f5f5',
          borderRadius: 12,
          padding: 10,
          marginBottom: 10
        }]}>
          <Text style={{
            fontSize: 14, 
            fontWeight: '600',
            color: '#333',
            marginBottom: 8
          }}>
            Dettaglio orari
          </Text>
          
          <View style={{flexDirection: 'row', flexWrap: 'wrap', gap: 6}}>
            {item.departure_company && (
              <View style={styles.timeCard}>
                <Ionicons name="car-outline" size={16} color="#1565c0" style={{marginRight: 4}} />
                <Text style={[styles.timeText, {color: '#1565c0'}]}>
                  Partenza: {formatTime(item.departure_company)}
                </Text>
              </View>
            )}
            
            {item.work_start_1 && item.work_end_1 && (
              <View style={styles.timeCard}>
                <Ionicons name="build-outline" size={16} color="#2e7d32" style={{marginRight: 4}} />
                <Text style={[styles.timeText, {color: '#2e7d32'}]}>
                  Lavoro: {formatTime(item.work_start_1)} - {formatTime(item.work_end_1)}
                </Text>
              </View>
            )}
            
            {item.work_start_2 && item.work_end_2 && (
              <View style={styles.timeCard}>
                <Ionicons name="build-outline" size={16} color="#2e7d32" style={{marginRight: 4}} />
                <Text style={[styles.timeText, {color: '#2e7d32'}]}>
                  2° Turno: {formatTime(item.work_start_2)} - {formatTime(item.work_end_2)}
                </Text>
              </View>
            )}
            
            {item.arrival_company && (
              <View style={styles.timeCard}>
                <Ionicons name="home-outline" size={16} color="#1565c0" style={{marginRight: 4}} />
                <Text style={[styles.timeText, {color: '#1565c0'}]}>
                  Rientro: {formatTime(item.arrival_company)}
                </Text>
              </View>
            )}
          </View>
          
          {/* Indicatore ore totali lavoro e viaggio */}
          <View style={{
            marginTop: 8, 
            flexDirection: 'row', 
            justifyContent: 'flex-end',
            alignItems: 'center'
          }}>
            <Text style={{fontSize: 12, color: '#555', marginRight: 6}}>Ore totali:</Text>
            <View style={{
              backgroundColor: '#e8f5e9',
              paddingVertical: 3,
              paddingHorizontal: 8,
              borderRadius: 10,
              minWidth: 60,
              alignItems: 'center'
            }}>
              <Text style={{color: '#2e7d32', fontWeight: '600'}}>
                {formatSafeHours(workHours)}h
              </Text>
            </View>
          </View>
        </View>

        {/* Interventi di reperibilità - con design migliorato */}
        {item.interventi && item.interventi.length > 0 && (
          <View style={{
            marginTop: 6, 
            marginBottom: 10,
            backgroundColor: '#f3e5f5', 
            borderRadius: 12, 
            padding: 10
          }}>
            <View style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginBottom: 8
            }}>
              <Ionicons name="call" size={18} color="#9C27B0" style={{marginRight: 6}} />
              <Text style={{
                fontWeight: 'bold', 
                color: '#9C27B0', 
                fontSize: 14
              }}>
                Interventi Reperibilità ({item.interventi.length})
              </Text>
            </View>
            
            {item.interventi.map((intervento, index) => (
              <View key={index} style={{
                marginBottom: 8,
                borderLeftWidth: 2,
                borderLeftColor: '#9C27B0',
                paddingLeft: 8
              }}>
                <Text style={{
                  fontSize: 12,
                  color: '#9C27B0',
                  fontWeight: '600',
                  marginBottom: 4
                }}>
                  Intervento {index + 1}
                </Text>
                
                <View style={{flexDirection: 'row', flexWrap: 'wrap', gap: 6}}>
                  {intervento.departure_company && intervento.arrival_site && (
                    <View style={[styles.timeCard, {backgroundColor: '#ede7f6'}]}>
                      <Ionicons name="car-outline" size={16} color="#9C27B0" style={{marginRight: 4}} />
                      <Text style={{fontSize: 12, color: '#9C27B0'}}>
                        Viaggio: {formatTime(intervento.departure_company)} - {formatTime(intervento.arrival_site)}
                      </Text>
                    </View>
                  )}
                  
                  {intervento.work_start_1 && intervento.work_end_1 && (
                    <View style={[styles.timeCard, {backgroundColor: '#ede7f6'}]}>
                      <Ionicons name="build-outline" size={16} color="#9C27B0" style={{marginRight: 4}} />
                      <Text style={{fontSize: 12, color: '#9C27B0'}}>
                        Lavoro: {formatTime(intervento.work_start_1)} - {formatTime(intervento.work_end_1)}
                      </Text>
                    </View>
                  )}
                  
                  {intervento.departure_return && intervento.arrival_company && (
                    <View style={[styles.timeCard, {backgroundColor: '#ede7f6'}]}>
                      <Ionicons name="home-outline" size={16} color="#9C27B0" style={{marginRight: 4}} />
                      <Text style={{fontSize: 12, color: '#9C27B0'}}>
                        Rientro: {formatTime(intervento.departure_return)} - {formatTime(intervento.arrival_company)}
                      </Text>
                    </View>
                  )}
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Dettaglio calcolo CCNL (riprogettato) */}
        {(standbyAllowance > 0 || standbyWorkPay > 0 || standbyTravelPay > 0 || travelPay > 0 || overtimePay > 0 || travelAllowance > 0 || note || dayType !== 'lavorativa') && (
          <View style={{
            marginVertical: 10,
            backgroundColor: '#e8eaf6',
            borderRadius: 12,
            padding: 12,
            elevation: 2,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.2,
            shadowRadius: 2
          }}>
            <View style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginBottom: 10,
              borderBottomWidth: 1,
              borderBottomColor: '#c5cae9',
              paddingBottom: 8
            }}>
              <Ionicons name="calculator-outline" size={18} color="#3f51b5" style={{marginRight: 8}} />
              <Text style={{
                fontWeight: 'bold',
                fontSize: 16,
                color: '#3f51b5'
              }}>
                Dettaglio calcolo CCNL
              </Text>
            </View>
            {/* Avviso ore inferiori a 8 */}
            {dayType === 'lavorativa' && workHours < 8 && (
              <View style={{
                backgroundColor: '#ffebee',
                borderRadius: 8,
                padding: 8,
                marginBottom: 10,
                borderLeftWidth: 4,
                borderLeftColor: '#d32f2f'
              }}>
                <Text style={{color: '#d32f2f', fontSize: 13}}>
                  <Ionicons name="alert-circle" size={16} color="#d32f2f" style={{marginRight: 4}} />
                  Ore segnate inferiori a 8. Completamento giornata necessario.
                </Text>
              </View>
            )}
            
            {/* Voci del calcolo */}
            <View style={{marginBottom: 10}}>
              {/* Giorni ferie/permesso */}
              {(dayType === 'ferie' || dayType === 'permesso') && (
                <View style={{
                  backgroundColor: '#e8f5e9', 
                  padding: 8, 
                  borderRadius: 8,
                  marginBottom: 8
                }}>
                  <Text style={{color: '#388e3c', fontWeight: 'bold'}}>
                    Retribuzione giornaliera: {formatCurrency(dailyRate)}
                  </Text>
                  <Text style={{color: '#1976d2', fontSize: 13, marginTop: 4}}>
                    Ore segnate: {workHours.toFixed(2)}h
                  </Text>
                  {workHours < 8 && (
                    <Text style={{color: '#d32f2f', fontSize: 12, marginTop: 4}}>
                      <Ionicons name="alert-circle-outline" size={12} color="#d32f2f" /> 
                      Ore inferiori a 8. Specifica come completare.
                    </Text>
                  )}
                </View>
              )}
              
              {/* Altri giorni non lavorativi */}
              {dayType !== 'lavorativa' && dayType !== 'ferie' && dayType !== 'permesso' && (
                <View style={{
                  backgroundColor: '#e8f5e9', 
                  padding: 8, 
                  borderRadius: 8,
                  marginBottom: 8
                }}>
                  <Text style={{color: '#388e3c', fontWeight: 'bold'}}>
                    Retribuzione giornaliera: {formatCurrency(dailyRate)}
                  </Text>
                </View>
              )}
              
              {/* SEZIONE ATTIVITÀ ORDINARIE */}
              {hasOrdinaryHours && (
                <View style={{marginBottom: 12, borderRadius: 8, overflow: 'hidden'}}>
                  {/* Intestazione sezione ordinarie */}
                  <View style={{
                    backgroundColor: '#e3f2fd', 
                    paddingVertical: 6, 
                    paddingHorizontal: 10, 
                    borderTopLeftRadius: 8,
                    borderTopRightRadius: 8
                  }}>
                    <Text style={{fontSize: 14, fontWeight: 'bold', color: '#1976d2'}}>
                      <Ionicons name="briefcase-outline" size={14} color="#1976d2" style={{marginRight: 4}} />
                      Attività Ordinarie
                    </Text>
                  </View>
                
                  {/* Giornaliero - Prime 8 ore (lavoro + viaggio) */}
                  {(breakdown.ordinary.hours.lavoro_giornaliera > 0 || breakdown.ordinary.hours.viaggio_giornaliera > 0) && (
                    <View style={{
                      padding: 10, 
                      backgroundColor: '#f7fbff',
                      borderBottomWidth: 1,
                      borderBottomColor: '#e0e0e0'
                    }}>
                      <View style={{flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3}}>
                        <Text style={{fontWeight: '600', color: '#333'}}>Giornaliero (prime 8h)</Text>
                        <Text style={{fontWeight: '500', color: '#333'}}>
                          {formatSafeHours((breakdown.ordinary.hours.lavoro_giornaliera || 0) + (breakdown.ordinary.hours.viaggio_giornaliera || 0))}
                        </Text>
                      </View>
                      
                      {breakdown.ordinary.earnings.giornaliera > 0 && (
                        <View style={{backgroundColor: '#e8f5e9', padding: 6, borderRadius: 4, marginTop: 3, marginBottom: 4}}>
                          <Text style={{color: '#388e3c', fontSize: 12}}>
                            {(() => {
                              const totalOrdinaryHours = (breakdown.ordinary.hours.lavoro_giornaliera || 0) + (breakdown.ordinary.hours.viaggio_giornaliera || 0);
                              const standardWorkDayHours = 8;
                              const dailyRate = safeSettings.contract?.dailyRate || 109.19;
                              
                              if (totalOrdinaryHours >= standardWorkDayHours) {
                                return `${dailyRate.toFixed(2).replace('.', ',')} € × 1 giorno = ${breakdown.ordinary.earnings.giornaliera.toFixed(2).replace('.', ',')} €`;
                              } else {
                                const percentage = (totalOrdinaryHours / standardWorkDayHours * 100).toFixed(0);
                                return `${dailyRate.toFixed(2).replace('.', ',')} € × ${percentage}% (${totalOrdinaryHours.toFixed(2).replace('.', ',')}h / 8h) = ${breakdown.ordinary.earnings.giornaliera.toFixed(2).replace('.', ',')} €`;
                              }
                            })()}
                          </Text>
                        </View>
                      )}
                      
                      <View style={{marginTop: 2}}>
                        {breakdown.ordinary.hours.lavoro_giornaliera > 0 && (
                          <Text style={{color: '#666', fontSize: 12}}>
                            • Lavoro: {formatSafeHours(breakdown.ordinary.hours.lavoro_giornaliera)}
                          </Text>
                        )}
                        {breakdown.ordinary.hours.viaggio_giornaliera > 0 && (
                          <Text style={{color: '#666', fontSize: 12}}>
                            • Viaggio: {formatSafeHours(breakdown.ordinary.hours.viaggio_giornaliera)}
                          </Text>
                        )}
                      </View>
                    </View>
                  )}
                  
                  {/* Viaggio extra (oltre 8h) */}
                  {breakdown.ordinary.hours.viaggio_extra > 0 && (
                    <View style={{
                      padding: 10, 
                      backgroundColor: '#f7fbff',
                      borderBottomWidth: 1,
                      borderBottomColor: '#e0e0e0'
                    }}>
                      <View style={{flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3}}>
                        <Text style={{fontWeight: '600', color: '#333'}}>Viaggio extra (oltre 8h)</Text>
                        <Text style={{fontWeight: '500', color: '#333'}}>
                          {formatSafeHours(breakdown.ordinary.hours.viaggio_extra)}
                        </Text>
                      </View>
                      
                      {breakdown.ordinary.earnings.viaggio_extra > 0 && (
                        <View style={{backgroundColor: '#e8f5e9', padding: 6, borderRadius: 4, marginVertical: 4}}>
                          <Text style={{color: '#1976d2', fontSize: 12}}>
                            {((safeSettings.contract?.hourlyRate || 16.41) * (safeSettings.travelCompensationRate || 1.0)).toFixed(2).replace('.', ',')} € × {formatSafeHours(breakdown.ordinary.hours.viaggio_extra)} = {breakdown.ordinary.earnings.viaggio_extra.toFixed(2).replace('.', ',')} €
                          </Text>
                        </View>
                      )}
                    </View>
                  )}
                  
                  {/* Lavoro extra (oltre 8h) */}
                  {breakdown.ordinary.hours.lavoro_extra > 0 && (
                    <View style={{
                      padding: 10, 
                      backgroundColor: '#f7fbff',
                      borderBottomWidth: 1,
                      borderBottomColor: '#e0e0e0'
                    }}>
                      <View style={{flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3}}>
                        <Text style={{fontWeight: '600', color: '#333'}}>Lavoro extra (oltre 8h)</Text>
                        <Text style={{fontWeight: '500', color: '#333'}}>
                          {formatSafeHours(breakdown.ordinary.hours.lavoro_extra)}
                        </Text>
                      </View>
                      
                      {breakdown.ordinary.earnings.lavoro_extra > 0 && (
                        <View style={{backgroundColor: '#fff3e0', padding: 6, borderRadius: 4, marginVertical: 4}}>
                          <Text style={{color: '#ef6c00', fontSize: 12}}>
                            {((safeSettings.contract?.hourlyRate || 16.41) * (safeSettings.contract?.overtimeRates?.day || 1.2)).toFixed(2).replace('.', ',')} € × {formatSafeHours(breakdown.ordinary.hours.lavoro_extra)} = {breakdown.ordinary.earnings.lavoro_extra.toFixed(2).replace('.', ',')} €
                          </Text>
                        </View>
                      )}
                    </View>
                  )}
                  
                  {/* Totale ordinario */}
                  <View style={{
                    backgroundColor: '#e3f2fd',
                    padding: 10,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    borderBottomLeftRadius: 8,
                    borderBottomRightRadius: 8
                  }}>
                    <Text style={{fontWeight: 'bold', color: '#1976d2'}}>Totale ordinario</Text>
                    <Text style={{fontWeight: 'bold', color: '#1976d2'}}>{formatCurrency(breakdown.ordinary.total || 0)}</Text>
                  </View>
                </View>
              )}
              
              {/* SEZIONE INTERVENTI REPERIBILITÀ */}
              {hasStandbyHours && (
                <View style={{marginBottom: 12, borderRadius: 8, overflow: 'hidden'}}>
                  {/* Intestazione sezione reperibilità */}
                  <View style={{
                    backgroundColor: '#f3e5f5', 
                    paddingVertical: 6, 
                    paddingHorizontal: 10, 
                    borderTopLeftRadius: 8,
                    borderTopRightRadius: 8
                  }}>
                    <Text style={{fontSize: 14, fontWeight: 'bold', color: '#9C27B0'}}>
                      <Ionicons name="phone-portrait" size={14} color="#9C27B0" style={{marginRight: 4}} />
                      Interventi Reperibilità
                    </Text>
                  </View>
                
                  {/* Lavoro diurno reperibilità */}
                  {breakdown.standby.workHours?.ordinary > 0 && (
                    <View style={{
                      padding: 10, 
                      backgroundColor: '#faf5fb',
                      borderBottomWidth: 1,
                      borderBottomColor: '#e0e0e0'
                    }}>
                      <View style={{flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3}}>
                        <Text style={{fontWeight: '600', color: '#333'}}>Lavoro diurno</Text>
                        <Text style={{fontWeight: '500', color: '#333'}}>
                          {formatSafeHours(breakdown.standby.workHours.ordinary)}
                        </Text>
                      </View>
                      
                      {breakdown.standby.workEarnings?.ordinary > 0 && (
                        <View style={{backgroundColor: '#f3e5f5', padding: 6, borderRadius: 4, marginVertical: 4}}>
                          <Text style={{color: '#9C27B0', fontSize: 12}}>
                            {((safeSettings.contract?.hourlyRate || 16.41) * (safeSettings.contract?.overtimeRates?.day || 1.2)).toFixed(2).replace('.', ',')} € × {formatSafeHours(breakdown.standby.workHours.ordinary)} = {breakdown.standby.workEarnings.ordinary.toFixed(2).replace('.', ',')} €
                          </Text>
                        </View>
                      )}
                    </View>
                  )}
                  
                  {/* Lavoro notturno reperibilità */}
                  {breakdown.standby.workHours?.night > 0 && (
                    <View style={{
                      padding: 10, 
                      backgroundColor: '#faf5fb',
                      borderBottomWidth: 1,
                      borderBottomColor: '#e0e0e0'
                    }}>
                      <View style={{flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3}}>
                        <Text style={{fontWeight: '600', color: '#333'}}>Lavoro notturno</Text>
                        <Text style={{fontWeight: '500', color: '#333'}}>
                          {formatSafeHours(breakdown.standby.workHours.night)}
                        </Text>
                      </View>
                      
                      {breakdown.standby.workEarnings?.night > 0 && (
                        <View style={{backgroundColor: '#f3e5f5', padding: 6, borderRadius: 4, marginVertical: 4}}>
                          <Text style={{color: '#9C27B0', fontSize: 12}}>
                            {((safeSettings.contract?.hourlyRate || 16.41) * (safeSettings.contract?.overtimeRates?.nightUntil22 || 1.25)).toFixed(2).replace('.', ',')} € × {formatSafeHours(breakdown.standby.workHours.night)} = {breakdown.standby.workEarnings.night.toFixed(2).replace('.', ',')} €
                          </Text>
                        </View>
                      )}
                    </View>
                  )}
                  
                  {/* Viaggio reperibilità */}
                  {(breakdown.standby.travelHours?.ordinary > 0 || breakdown.standby.travelHours?.night > 0) && (
                    <View style={{
                      padding: 10, 
                      backgroundColor: '#faf5fb',
                      borderBottomWidth: 1,
                      borderBottomColor: '#e0e0e0'
                    }}>
                      <View style={{flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3}}>
                        <Text style={{fontWeight: '600', color: '#333'}}>Viaggio reperibilità</Text>
                        <Text style={{fontWeight: '500', color: '#333'}}>
                          {formatSafeHours((breakdown.standby.travelHours?.ordinary || 0) + (breakdown.standby.travelHours?.night || 0))}
                        </Text>
                      </View>
                      
                      {breakdown.standby.travelEarnings?.total > 0 && (
                        <View style={{backgroundColor: '#f3e5f5', padding: 6, borderRadius: 4, marginVertical: 4}}>
                          <Text style={{color: '#9C27B0', fontSize: 12}}>
                            {((safeSettings.contract?.hourlyRate || 16.41) * (safeSettings.travelCompensationRate || 1.0)).toFixed(2).replace('.', ',')} € × {formatSafeHours((breakdown.standby.travelHours?.ordinary || 0) + (breakdown.standby.travelHours?.night || 0))} = {breakdown.standby.travelEarnings.total.toFixed(2).replace('.', ',')} €
                          </Text>
                        </View>
                      )}
                    </View>
                  )}
                  
                  {/* Totale reperibilità */}
                  <View style={{
                    backgroundColor: '#f3e5f5',
                    padding: 10,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    borderBottomLeftRadius: 8,
                    borderBottomRightRadius: 8
                  }}>
                    <Text style={{fontWeight: 'bold', color: '#9C27B0'}}>Totale interventi</Text>
                    <Text style={{fontWeight: 'bold', color: '#9C27B0'}}>{formatCurrency((breakdown.standby?.totalEarnings || 0) - (breakdown.standby?.dailyIndemnity || 0))}</Text>
                  </View>
                </View>
              )}
              
              {/* SEZIONE INDENNITÀ E BUONI */}
              {hasAllowances && (
                <View style={{marginBottom: 12, borderRadius: 8, overflow: 'hidden'}}>
                  {/* Intestazione sezione indennità */}
                  <View style={{
                    backgroundColor: '#e0f2f1', 
                    paddingVertical: 6, 
                    paddingHorizontal: 10, 
                    borderTopLeftRadius: 8,
                    borderTopRightRadius: 8
                  }}>
                    <Text style={{fontSize: 14, fontWeight: 'bold', color: '#00796b'}}>
                      <Ionicons name="wallet-outline" size={14} color="#00796b" style={{marginRight: 4}} />
                      Indennità e Buoni
                    </Text>
                  </View>
                
                  {/* Indennità trasferta */}
                  {breakdown.allowances?.travel > 0 && (
                    <View style={{
                      padding: 10, 
                      backgroundColor: '#f6fffe',
                      borderBottomWidth: 1,
                      borderBottomColor: '#e0e0e0'
                    }}>
                      <View style={{flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3}}>
                        <View style={{flex: 1}}>
                          <Text style={{fontWeight: '600', color: '#333'}}>Indennità trasferta</Text>
                          <Text style={{color: '#666', fontSize: 12}}>
                            {(item.trasfertaPercent * 100) || 100}% dell'importo giornaliero
                          </Text>
                        </View>
                        <Text style={{fontWeight: '600', color: '#00796b'}}>{formatCurrency(breakdown.allowances.travel)}</Text>
                      </View>
                    </View>
                  )}
                  
                  {/* Indennità reperibilità */}
                  {breakdown.allowances?.standby > 0 && (
                    <View style={{
                      padding: 10, 
                      backgroundColor: '#f6fffe',
                      borderBottomWidth: 1,
                      borderBottomColor: '#e0e0e0'
                    }}>
                      <View style={{flexDirection: 'row', justifyContent: 'space-between', marginBottom: 3}}>
                        <View style={{flex: 1}}>
                          <Text style={{fontWeight: '600', color: '#333'}}>Indennità reperibilità</Text>
                          <Text style={{color: '#666', fontSize: 12}}>
                            Tariffa giornaliera
                          </Text>
                        </View>
                        <Text style={{fontWeight: '600', color: '#9C27B0'}}>{formatCurrency(breakdown.allowances.standby)}</Text>
                      </View>
                    </View>
                  )}
                  
                  {/* Totale complessivo */}
                  <View style={{
                    backgroundColor: '#e0f2f1',
                    padding: 10,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    borderBottomLeftRadius: 8,
                    borderBottomRightRadius: 8
                  }}>
                    <Text style={{fontWeight: 'bold', color: '#00796b'}}>Totale indennità</Text>
                    <Text style={{fontWeight: 'bold', color: '#00796b'}}>{formatCurrency((breakdown.allowances?.travel || 0) + (breakdown.allowances?.standby || 0))}</Text>
                  </View>
                </View>
              )}
              
              {/* TOTALE COMPLESSIVO */}
              <View style={{
                flexDirection: 'row', 
                justifyContent: 'space-between',
                alignItems: 'center',
                marginTop: 12,
                backgroundColor: '#3f51b5',
                borderRadius: 8,
                padding: 12,
                elevation: 2,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.3,
                shadowRadius: 2
              }}>
                <Text style={{fontWeight: 'bold', color: '#fff', fontSize: 15}}>
                  TOTALE GIORNATA
                </Text>
                <Text style={{fontWeight: 'bold', color: '#fff', fontSize: 15}}>
                  {formatCurrency(breakdown.total || 0)}
                </Text>
              </View>
            </View>
            
            {/* Nota */}
            {note && (
              <View style={{
                backgroundColor: '#fff9c4', 
                borderRadius: 8, 
                padding: 8,
                marginTop: 4
              }}>
                <Text style={{color: '#333', fontSize: 13}}>
                  <Ionicons name="document-text-outline" size={14} color="#333" style={{marginRight: 4}} />
                  {note}
                </Text>
              </View>
            )}
            
            {/* Nota informativa sulla modalità di calcolo */}
            <Text style={{color: '#888', fontSize: 11, marginTop: 10}}>
              <Ionicons name="information-circle-outline" size={12} color="#888" style={{marginRight: 2}} />
              Le ore di viaggio vengono pagate solo se eccedenti le 8h totali (lavoro+viaggio). La retribuzione base è calcolata con tariffa giornaliera se la somma raggiunge 8h.
            </Text>
          </View>
        )}
        
        {/* Badge conferma reperibilità */}
        {item.is_standby_day === 1 && (
          <View style={{
            flexDirection: 'row',
            alignItems: 'center',
            backgroundColor: isStandbyConfirmed ? '#e8f5e9' : '#f5f5f5',
            borderRadius: 8,
            paddingVertical: 6,
            paddingHorizontal: 10,
            marginVertical: 6
          }}>
            <Ionicons name={isStandbyConfirmed ? 'checkmark-circle' : 'time'} 
                     size={16} 
                     color={isStandbyConfirmed ? '#388e3c' : '#757575'} 
                     style={{marginRight: 6}} />
            <Text style={{
              fontSize: 12,
              color: isStandbyConfirmed ? '#388e3c' : '#757575'
            }}>
              {isStandbyConfirmed ? 'Reperibilità confermata' : 'In attesa di conferma reperibilità'}
            </Text>
          </View>
        )}
        {/* Rimborsi pasti - nuova UI */}
        {((breakdown.mealAllowances?.lunch?.voucher || 0) > 0 || 
          (breakdown.mealAllowances?.lunch?.cash || 0) > 0 || 
          (breakdown.mealAllowances?.dinner?.voucher || 0) > 0 || 
          (breakdown.mealAllowances?.dinner?.cash || 0) > 0) && (
          <View style={{
            marginTop: 10,
            backgroundColor: '#e0f7fa',
            borderRadius: 12,
            padding: 12
          }}>
            <View style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginBottom: 10,
              borderBottomWidth: 1,
              borderBottomColor: '#b2ebf2',
              paddingBottom: 8
            }}>
              <Ionicons name="restaurant-outline" size={18} color="#00838f" style={{marginRight: 8}} />
              <Text style={{
                fontWeight: 'bold',
                fontSize: 15,
                color: '#00838f'
              }}>
                Rimborsi pasti
              </Text>
            </View>
            
            <View style={{flexDirection: 'row', flexWrap: 'wrap', gap: 8}}>
              {/* Pranzo voucher */}
              {(breakdown.mealAllowances?.lunch?.voucher || 0) > 0 && (
                <View style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: '#e3f2fd',
                  borderRadius: 12,
                  paddingVertical: 8,
                  paddingHorizontal: 12,
                  elevation: 1,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.1,
                  shadowRadius: 1
                }}>
                  <Ionicons name="fast-food" size={16} color="#1976d2" style={{marginRight: 8}} />
                  <View>
                    <Text style={{color: '#1976d2', fontWeight: 'bold', fontSize: 13}}>Pranzo Voucher</Text>
                    <Text style={{color: '#1976d2', fontSize: 12}}>
                      {safeSettings.mealAllowances?.lunch?.voucherAmount ? formatCurrency(safeSettings.mealAllowances.lunch.voucherAmount) : ''}
                    </Text>
                  </View>
                </View>
              )}
              
              {/* Pranzo cash */}
              {(breakdown.mealAllowances?.lunch?.cash || 0) > 0 && (
                <View style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: '#fff3e0',
                  borderRadius: 12,
                  paddingVertical: 8,
                  paddingHorizontal: 12,
                  elevation: 1,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.1,
                  shadowRadius: 1
                }}>
                  <Ionicons name="cash" size={16} color="#ef6c00" style={{marginRight: 8}} />
                  <View>
                    <Text style={{color: '#ef6c00', fontWeight: 'bold', fontSize: 13}}>Pranzo Cash</Text>
                    <Text style={{color: '#ef6c00', fontSize: 12}}>
                      {formatCurrency(breakdown.mealAllowances.lunch.cash)}
                    </Text>
                  </View>
                </View>
              )}
              
              {/* Cena voucher */}
              {(breakdown.mealAllowances?.dinner?.voucher || 0) > 0 && (
                <View style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: '#ede7f6',
                  borderRadius: 12,
                  paddingVertical: 8,
                  paddingHorizontal: 12,
                  elevation: 1,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.1,
                  shadowRadius: 1
                }}>
                  <Ionicons name="restaurant" size={16} color="#7e57c2" style={{marginRight: 8}} />
                  <View>
                    <Text style={{color: '#7e57c2', fontWeight: 'bold', fontSize: 13}}>Cena Voucher</Text>
                    <Text style={{color: '#7e57c2', fontSize: 12}}>
                      {safeSettings.mealAllowances?.dinner?.voucherAmount ? formatCurrency(safeSettings.mealAllowances.dinner.voucherAmount) : ''}
                    </Text>
                  </View>
                </View>
              )}
              
              {/* Cena cash */}
              {(breakdown.mealAllowances?.dinner?.cash || 0) > 0 && (
                <View style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: '#fff3e0',
                  borderRadius: 12,
                  paddingVertical: 8,
                  paddingHorizontal: 12,
                  elevation: 1,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.1,
                  shadowRadius: 1
                }}>
                  <Ionicons name="cash" size={16} color="#ef6c00" style={{marginRight: 8}} />
                  <View>
                    <Text style={{color: '#ef6c00', fontWeight: 'bold', fontSize: 13}}>Cena Cash</Text>
                    <Text style={{color: '#ef6c00', fontSize: 12}}>
                      {formatCurrency(breakdown.mealAllowances.dinner.cash)}
                    </Text>
                  </View>
                </View>
              )}
            </View>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  const calculateTotalHours = (entry) => {
    let totalMinutes = 0;
    
    // Calculate work hours
    if (entry.work_start_1 && entry.work_end_1) {
      totalMinutes += calculateTimeDiff(entry.work_start_1, entry.work_end_1);
    }
    if (entry.work_start_2 && entry.work_end_2) {
      totalMinutes += calculateTimeDiff(entry.work_start_2, entry.work_end_2);
    }
    
    // Calculate travel hours
    if (entry.departure_company && entry.arrival_site) {
      totalMinutes += calculateTimeDiff(entry.departure_company, entry.arrival_site);
    }
    if (entry.departure_return && entry.arrival_company) {
      totalMinutes += calculateTimeDiff(entry.departure_return, entry.arrival_company);
    }

    // Aggiungi ore da interventi di reperibilità
    if (entry.interventi && Array.isArray(entry.interventi)) {
      entry.interventi.forEach(intervento => {
        if (intervento.work_start_1 && intervento.work_end_1) {
          totalMinutes += calculateTimeDiff(intervento.work_start_1, intervento.work_end_1);
        }
        if (intervento.work_start_2 && intervento.work_end_2) {
          totalMinutes += calculateTimeDiff(intervento.work_start_2, intervento.work_end_2);
        }
        if (intervento.departure_company && intervento.arrival_site) {
          totalMinutes += calculateTimeDiff(intervento.departure_company, intervento.arrival_site);
        }
        if (intervento.departure_return && intervento.arrival_company) {
          totalMinutes += calculateTimeDiff(intervento.departure_return, intervento.arrival_company);
        }
      });
    }
    
    return totalMinutes / 60;
  };

  const calculateTimeDiff = (startTime, endTime) => {
    if (!startTime || !endTime) return 0;
    
    const [startHours, startMinutes] = startTime.split(':').map(Number);
    const [endHours, endMinutes] = endTime.split(':').map(Number);
    
    const startTotalMinutes = startHours * 60 + startMinutes;
    let endTotalMinutes = endHours * 60 + endMinutes;
    
    // Handle overnight work
    if (endTotalMinutes < startTotalMinutes) {
      endTotalMinutes += 24 * 60;
    }
    
    return endTotalMinutes - startTotalMinutes;
  };

  // Salvataggio reale entry su DatabaseService (SQLite)
  const saveEntry = async (entry) => {
    try {
      // Mappa i campi per compatibilità DB
      const dbEntry = {
        ...entry,
        siteName: entry.site_name || entry.siteName || '',
        vehicleDriven: entry.vehicle_driven || entry.vehicleDriven || '',
        departureCompany: entry.departure_company || entry.departureCompany || '',
        arrivalSite: entry.arrival_site || entry.arrivalSite || '',
        workStart1: entry.work_start_1 || entry.workStart1 || '',
        workEnd1: entry.work_end_1 || entry.workEnd1 || '',
        workStart2: entry.work_start_2 || entry.workStart2 || '',
        workEnd2: entry.work_end_2 || entry.workEnd2 || '',
        departureReturn: entry.departure_return || entry.departureReturn || '',
        arrivalCompany: entry.arrival_company || entry.arrivalCompany || '',
        standbyDeparture: entry.standby_departure || entry.standbyDeparture || '',
        standbyArrival: entry.standby_arrival || entry.standbyArrival || '',
        standbyWorkStart1: entry.standby_work_start_1 || entry.standbyWorkStart1 || '',
        standbyWorkEnd1: entry.standby_work_end_1 || entry.standbyWorkEnd1 || '',
        standbyWorkStart2: entry.standby_work_start_2 || entry.standbyWorkStart2 || '',
        standbyWorkEnd2: entry.standby_work_end_2 || entry.standbyWorkEnd2 || '',
        standbyReturnDeparture: entry.standby_return_departure || entry.standbyReturnDeparture || '',
        standbyReturnArrival: entry.standby_return_arrival || entry.standbyReturnArrival || '',
        interventi: entry.interventi || [], // Assicura che l'array interventi sia passato
        mealLunchVoucher: entry.meal_lunch_voucher || entry.mealLunchVoucher || 0,
        mealLunchCash: entry.meal_lunch_cash || entry.mealLunchCash || 0,
        mealDinnerVoucher: entry.meal_dinner_voucher || entry.mealDinnerVoucher || 0,
        mealDinnerCash: entry.meal_dinner_cash || entry.mealDinnerCash || 0,
        travelAllowance: entry.travelAllowance || 0,
        standbyAllowance: entry.standbyAllowance || 0,
        isStandbyDay: entry.is_standby_day || entry.isStandbyDay || 0,
        totalEarnings: entry.total_earnings || entry.totalEarnings || 0,
        notes: entry.note || entry.notes || '',
      };
      await DatabaseService.insertWorkEntry(dbEntry);
      Alert.alert('Salvataggio','Inserimento salvato su database!');
      refreshEntries();
    } catch (e) {
      Alert.alert('Errore','Errore durante il salvataggio su database.');
    }
  };

  const handleDayTypeChange = async (entry, newDayType) => {
    try {
      // Crea un work entry aggiornato con il nuovo tipo giornata
      const updatedEntry = { ...entry, day_type: newDayType };
      
      // Ricalcola il totale degli earnings usando lo stesso servizio di calcolo
      const safeSettings = getSafeSettings(settings);
      const breakdown = calculateItemBreakdown(updatedEntry, settings);
      
      // Assicuriamoci che il breakdown.total esista, altrimenti utilizziamo 0
      const totalEarnings = breakdown.total || 0;
      console.log(`Nuovo totale guadagni per ${updatedEntry.date}: ${totalEarnings}`);
      
      // Aggiorna l'entry includendo il totale ricalcolato
      await DatabaseService.updateWorkEntry({ 
        ...updatedEntry, 
        total_earnings: totalEarnings
      });
      
      // Ricarica gli inserimenti per mostrare i totali aggiornati
      refreshEntries();
    } catch (e) {
      console.error('Errore aggiornamento tipo giornata:', e);
      Alert.alert('Errore', 'Impossibile aggiornare il tipo giornata.');
    }
  };

  if (isLoading && entries.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#2196F3" />
          <Text style={styles.loadingText}>Caricamento inserimenti...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header rivisto con solo pulsante nuovo inserimento più visibile */}
      <View style={[styles.header, { flexDirection: 'column', alignItems: 'stretch', paddingBottom: 15 }]}>
        {/* Pulsante Nuovo grande e ben visibile in alto */}
        <TouchableOpacity 
          style={{
            backgroundColor: '#1976D2',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            paddingVertical: 14,
            borderRadius: 10,
            elevation: 6,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 3 },
            shadowOpacity: 0.2,
            shadowRadius: 4,
            marginBottom: 12,
            borderWidth: 1,
            borderColor: '#1565C0',
          }} 
          onPress={handleNewEntry} 
          onLongPress={()=>Alert.alert('Nuovo inserimento','Aggiungi un nuovo inserimento orario per la giornata selezionata.')}
        >
          <Ionicons name="add-circle" size={32} color="white" />
          <Text style={{

        {/* Seconda riga: solo titolo */}
        <View style={{ 
          flexDirection: 'row', 
          justifyContent: 'center', 
          alignItems: 'center', 
          marginTop: 5,
          paddingTop: 10,
          borderTopWidth: 1,
          borderTopColor: '#e0e0e0'
        }}>
          <Text style={styles.headerTitle}>Storico Inserimenti</Text>
        </View>
      </View>
      <FlatList
        data={entries}
        renderItem={renderWorkEntry}
        keyExtractor={(item) => item.id.toString()}
        style={styles.list}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={isLoading} onRefresh={refreshEntries} tintColor="#2196F3" title="Aggiornamento..." titleColor="#2196F3" />
        }
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={() => (
          <View>
            <View style={{
              flexDirection: 'row', 
              alignItems: 'center', 
              padding: 10, 
              backgroundColor: '#e3f2fd', 
              borderRadius: 8,
              marginBottom: 8
            }}>
              <Ionicons name="information-circle-outline" size={20} color="#1976d2" style={{marginRight: 8}} />
              <Text style={{color: '#1976d2', fontSize: 14}}>
                Visualizzazione completa di tutti gli inserimenti
              </Text>
            </View>
          </View>
        )}
      />
      {/* Modal selezione tipo giornata */}
      <Modal
        visible={dayTypeModalVisible}
        transparent
        animationType="slide"
        onRequestClose={closeDayTypeModal}
      >
        <View style={{flex:1,backgroundColor:'rgba(0,0,0,0.3)',justifyContent:'center',alignItems:'center'}}>
          <View style={{backgroundColor:'#fff',borderRadius:12,padding:20,minWidth:260}}>
            <Text style={{fontWeight:'bold',fontSize:17,marginBottom:10}}>Seleziona tipo giornata</Text>
            <Picker
              selectedValue={selectedDayTypeValue}
              onValueChange={setSelectedDayTypeValue}
              style={{height:40,marginBottom:10}}
            >
              {Object.entries(dayTypeLabels).map(([key, val]) => (
                <Picker.Item key={key} label={val.label} value={key} />
              ))}
            </Picker>
            <View style={{flexDirection:'row',justifyContent:'flex-end',marginTop:10}}>
              <TouchableOpacity onPress={closeDayTypeModal} style={{marginRight:16}}>
                <Text style={{color:'#757575',fontWeight:'bold'}}>Annulla</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={confirmDayTypeChange}>
                <Text style={{color:'#2196F3',fontWeight:'bold'}}>Conferma</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },

  header: {
    backgroundColor: 'white',
    paddingHorizontal: 16,
    paddingTop: 15,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 2
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  // Stili vecchi mantenuti per compatibilità
  addButton: {
    backgroundColor: '#2196F3',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
  },
  addButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 5,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 20,
    marginBottom: 10,
  },
  emptySubtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    lineHeight: 24,
  },
  list: {
    flex: 1,
  },
  listContent: {
    padding: 15,
  },
  entryCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  entryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  dateContainer: {
    alignItems: 'center',
    marginRight: 15,
  }
});

export default TimeEntryScreen;
