import { 
  CCNL_CONTRACTS, 
  calculateOvertimeRate, 
  isNightWork, 
  getWorkDayHours,
  MEAL_TIMES 
} from '../constants';
import { isItalianHoliday } from '../constants/holidays';

class CalculationService {
  constructor() {
    this.defaultContract = CCNL_CONTRACTS.METALMECCANICO_PMI_L5;
  }

  // Parse time string to minutes from midnight
  parseTime(timeString) {
    if (!timeString) return null;
    const [hours, minutes] = timeString.split(':').map(Number);
    return hours * 60 + minutes;
  }

  // Convert minutes to hours
  minutesToHours(minutes) {
    return minutes / 60;
  }

  // Calculate time difference in minutes
  calculateTimeDifference(startTime, endTime) {
    const start = this.parseTime(startTime);
    const end = this.parseTime(endTime);
    
    if (start === null || end === null) return 0;
    
    // Handle overnight work (end time next day)
    if (end < start) {
      return (24 * 60 - start) + end;
    }
    
    return end - start;
  }

  // Calculate work hours from work entry
  calculateWorkHours(workEntry) {
    let totalWorkMinutes = 0;
    
    // First work shift
    if (workEntry.workStart1 && workEntry.workEnd1) {
      totalWorkMinutes += this.calculateTimeDifference(workEntry.workStart1, workEntry.workEnd1);
    }
    
    // Second work shift
    if (workEntry.workStart2 && workEntry.workEnd2) {
      totalWorkMinutes += this.calculateTimeDifference(workEntry.workStart2, workEntry.workEnd2);
    }
    
    return this.minutesToHours(totalWorkMinutes);
  }

  // Calculate travel hours
  calculateTravelHours(workEntry) {
    let totalTravelMinutes = 0;
    
    // Outbound travel
    if (workEntry.departureCompany && workEntry.arrivalSite) {
      totalTravelMinutes += this.calculateTimeDifference(workEntry.departureCompany, workEntry.arrivalSite);
    }
    
    // Return travel
    if (workEntry.departureReturn && workEntry.arrivalCompany) {
      totalTravelMinutes += this.calculateTimeDifference(workEntry.departureReturn, workEntry.arrivalCompany);
    }
    
    return this.minutesToHours(totalTravelMinutes);
  }

  // Calculate standby work hours
  calculateStandbyWorkHours(workEntry) {
    let totalStandbyMinutes = 0;
    if (workEntry.interventi && Array.isArray(workEntry.interventi)) {
      workEntry.interventi.forEach(intervento => {
        if (intervento.work_start_1 && intervento.work_end_1) {
          totalStandbyMinutes += this.calculateTimeDifference(intervento.work_start_1, intervento.work_end_1);
        }
        if (intervento.work_start_2 && intervento.work_end_2) {
          totalStandbyMinutes += this.calculateTimeDifference(intervento.work_start_2, intervento.work_end_2);
        }
      });
    } else {
      // Fallback per la vecchia struttura dati
      if (workEntry.standbyWorkStart1 && workEntry.standbyWorkEnd1) {
        totalStandbyMinutes += this.calculateTimeDifference(workEntry.standbyWorkStart1, workEntry.standbyWorkEnd1);
      }
      if (workEntry.standbyWorkStart2 && workEntry.standbyWorkEnd2) {
        totalStandbyMinutes += this.calculateTimeDifference(workEntry.standbyWorkStart2, workEntry.standbyWorkEnd2);
      }
    }
    return this.minutesToHours(totalStandbyMinutes);
  }

  // Calculate standby travel hours
  calculateStandbyTravelHours(workEntry) {
    let totalStandbyTravelMinutes = 0;
    if (workEntry.interventi && Array.isArray(workEntry.interventi)) {
      workEntry.interventi.forEach(intervento => {
        if (intervento.departure_company && intervento.arrival_site) {
          totalStandbyTravelMinutes += this.calculateTimeDifference(intervento.departure_company, intervento.arrival_site);
        }
        if (intervento.departure_return && intervento.arrival_company) {
          totalStandbyTravelMinutes += this.calculateTimeDifference(intervento.departure_return, intervento.arrival_company);
        }
      });
    } else {
      // Fallback per la vecchia struttura dati
      if (workEntry.standbyDeparture && workEntry.standbyArrival) {
        totalStandbyTravelMinutes += this.calculateTimeDifference(workEntry.standbyDeparture, workEntry.standbyArrival);
      }
      if (workEntry.standbyReturnDeparture && workEntry.standbyReturnArrival) {
        totalStandbyTravelMinutes += this.calculateTimeDifference(workEntry.standbyReturnDeparture, workEntry.standbyReturnArrival);
      }
    }
    return this.minutesToHours(totalStandbyTravelMinutes);
  }

  // Calculate overtime hours based on work time and contract
  calculateOvertimeDetails(workHours, travelHours, contract = this.defaultContract) {
    const standardWorkDay = getWorkDayHours();
    const totalHours = workHours + travelHours;
    
    let regularHours = 0;
    let overtimeHours = 0;
    
    if (totalHours <= standardWorkDay) {
      regularHours = totalHours;
    } else {
      regularHours = standardWorkDay;
      overtimeHours = totalHours - standardWorkDay;
    }
    
    return {
      regularHours,
      overtimeHours,
      totalHours
    };
  }

  // Calcola la retribuzione giornaliera con tutte le maggiorazioni CCNL
  calculateDailyEarnings(workEntry, settings) {
    const contract = settings.contract || this.defaultContract;
    const baseRate = contract.hourlyRate || (contract.monthlySalary / 173);
    const dailyRate = contract.dailyRate || (contract.monthlySalary / 26);
    const travelCompensationRate = settings.travelCompensationRate || 1.0;
    const travelHoursSetting = settings.travelHoursSetting || 'EXCESS_AS_TRAVEL';
    const standbySettings = settings.standbySettings || {};
    const standbyDays = standbySettings.standbyDays || {};
    const dailyAllowance = parseFloat(standbySettings.dailyAllowance) || 0;

    // Calcolo ore base
    const workHours = this.calculateWorkHours(workEntry);
    const travelHours = this.calculateTravelHours(workEntry);
    const standbyWorkHours = this.calculateStandbyWorkHours(workEntry);
    const standbyTravelHours = this.calculateStandbyTravelHours(workEntry);

    // Determina se il giorno è festivo o domenica
    const dateObj = workEntry.date ? new Date(workEntry.date) : new Date();
    const isSunday = dateObj.getDay() === 0;
    const isHoliday = isItalianHoliday(dateObj);
    // Corretto: considera anche il flag manuale dal form
    const isStandbyDay = (standbyDays && standbyDays[workEntry.date]?.selected) || workEntry.isStandbyDay === true || workEntry.isStandbyDay === 1;

    // Calcolo straordinari
    let overtimePay = 0;
    let overtimeHours = 0;
    let regularPay = 0;
    let regularHours = 0;
    let travelPay = 0;

    // LOGICA CCNL: paga base giornaliera se lavoro+viaggio >= 8h
    const standardWorkDay = getWorkDayHours();
    const totalRegularHours = workHours + travelHours;
    if (totalRegularHours >= standardWorkDay) {
      regularPay = dailyRate;
      regularHours = standardWorkDay;
      const extraHours = totalRegularHours - standardWorkDay;
      if (extraHours > 0) {
        if (travelHoursSetting === 'EXCESS_AS_TRAVEL') {
          // Le ore oltre 8h sono pagate come viaggio
          travelPay = extraHours * baseRate * travelCompensationRate;
          overtimeHours = 0;
        } else if (travelHoursSetting === 'EXCESS_AS_OVERTIME') {
          // Le ore oltre 8h sono pagate come straordinario
          let overtimeBonusRate = this.getHourlyRateWithBonus({
            baseRate,
            isOvertime: true,
            isNight: workEntry.isNight || false,
            isHoliday,
            isSunday
          });
          overtimePay = extraHours * overtimeBonusRate;
          overtimeHours = extraHours;
        } else {
          // Default: nessun extra
          overtimeHours = 0;
        }
      }
    } else {
      // Se meno di 8h, paga solo le ore effettive
      regularPay = baseRate * totalRegularHours;
      regularHours = totalRegularHours;
      overtimeHours = 0;
    }

    // Lavoro ordinario notturno/festivo/domenicale
    let ordinaryBonusPay = 0;
    if (!overtimeHours && (workEntry.isNight || isHoliday || isSunday)) {
      let ordinaryBonusRate = this.getHourlyRateWithBonus({
        baseRate,
        isOvertime: false,
        isNight: workEntry.isNight || false,
        isHoliday,
        isSunday
      });
      ordinaryBonusPay = totalRegularHours * (ordinaryBonusRate - baseRate);
    }

    // --- CALCOLO INTERVENTI DURANTE REPERIBILITÀ ---
    let standbyWorkPay = 0;
    if (standbyWorkHours > 0) {
      standbyWorkPay = this.calculateStandbyWorkEarnings(
        workEntry.standbyWorkStart1,
        workEntry.standbyWorkEnd1,
        workEntry.standbyWorkStart2,
        workEntry.standbyWorkEnd2,
        contract
      );
    }
    let standbyTravelPay = 0;
    if (standbyTravelHours > 0) {
      standbyTravelPay = standbyTravelHours * baseRate * travelCompensationRate;
    }

    // --- INDENNITÀ GIORNALIERA REPERIBILITÀ ---
    let standbyAllowance = 0;
    if ((workEntry.isStandbyDay === true || workEntry.isStandbyDay === 1) && dailyAllowance > 0) {
      standbyAllowance = dailyAllowance;
    }

    // --- INDENNITÀ TRASFERTA ---
    let travelAllowance = 0;
    const travelAllowanceSettings = settings.travelAllowance || {};
    const travelAllowanceEnabled = travelAllowanceSettings.enabled;
    const travelAllowanceAmount = parseFloat(travelAllowanceSettings.dailyAmount) || 0;
    const travelAllowanceOption = travelAllowanceSettings.option || 'WITH_TRAVEL';
    const autoActivate = travelAllowanceSettings.autoActivate;
    let travelAllowancePercent = 1.0;
    if (typeof workEntry.travelAllowancePercent === 'number') {
      travelAllowancePercent = workEntry.travelAllowancePercent;
    }
    if (travelAllowanceEnabled && travelAllowanceAmount > 0) {
      let attiva = false;
      const totalWorked = workHours + travelHours;
      const isFullDay = totalWorked >= 8;
      const isHalfDay = totalWorked > 0 && totalWorked < 8;
      const isStandbyNonLavorativo = isStandbyDay && standbyWorkHours > 0 && totalWorked === 0;
      switch (travelAllowanceOption) {
        case 'WITH_TRAVEL':
          attiva = travelHours > 0;
          break;
        case 'ALWAYS':
          attiva = true;
          break;
        case 'FULL_DAY_ONLY':
          attiva = isFullDay;
          break;
        case 'ALSO_ON_STANDBY':
          attiva = travelHours > 0 || isStandbyNonLavorativo;
          break;
        case 'FULL_ALLOWANCE_HALF_DAY':
          attiva = totalWorked > 0;
          break;
        case 'HALF_ALLOWANCE_HALF_DAY':
          attiva = totalWorked > 0;
          break;
        default:
          attiva = travelHours > 0;
      }
      if (attiva) {
        if (travelAllowanceOption === 'HALF_ALLOWANCE_HALF_DAY' && isHalfDay) {
          travelAllowance = travelAllowanceAmount / 2;
        } else {
          travelAllowance = travelAllowanceAmount * travelAllowancePercent;
        }
      }
    }

    // Gestione ferie e permessi: se il giorno è ferie o permesso, escludi dal calcolo retribuzione
    if (workEntry.ferie) {
      return {
        regularPay: 0,
        overtimePay: 0,
        ordinaryBonusPay: 0,
        travelPay: 0,
        standbyWorkPay: 0,
        standbyTravelPay: 0,
        standbyAllowance: 0,
        total: 0,
        breakdown: {
          ferie: true,
          permesso: false
        }
      };
    }
    if (workEntry.permesso) {
      return {
        regularPay: 0,
        overtimePay: 0,
        ordinaryBonusPay: 0,
        travelPay: 0,
        standbyWorkPay: 0,
        standbyTravelPay: 0,
        standbyAllowance: 0,
        total: 0,
        breakdown: {
          ferie: false,
          permesso: true
        }
      };
    }

    // Totale
    const total = regularPay + overtimePay + ordinaryBonusPay + travelPay + standbyWorkPay + standbyTravelPay + standbyAllowance + travelAllowance;
    
    // Alla fine di calculateDailyEarnings, prima del return
    const mealAllowances = {};
    if (workEntry.mealLunchVoucher === 1) mealAllowances.lunch = { type: 'voucher', amount: settings.mealAllowances?.lunch?.voucherAmount || 0 };
    if (workEntry.mealLunchCash > 0) mealAllowances.lunch = { type: 'cash', amount: workEntry.mealLunchCash };
    if (workEntry.mealDinnerVoucher === 1) mealAllowances.dinner = { type: 'voucher', amount: settings.mealAllowances?.dinner?.voucherAmount || 0 };
    if (workEntry.mealDinnerCash > 0) mealAllowances.dinner = { type: 'cash', amount: workEntry.mealDinnerCash };

    return {
      regularPay,
      overtimePay,
      ordinaryBonusPay,
      travelPay,
      standbyWorkPay,
      standbyTravelPay,
      standbyAllowance,
      travelAllowance,
      total,
      breakdown: {
        workHours,
        travelHours,
        standbyWorkHours,
        standbyTravelHours,
        regularHours,
        overtimeHours,
        isStandbyDay
      },
      note: workEntry.isStandbyDay ? 'Indennità reperibilità inclusa. Il CCNL Metalmeccanico PMI non prevede una retribuzione aggiuntiva per la prima uscita: ogni intervento è retribuito secondo le maggiorazioni orarie.' : undefined,
      mealAllowances,
    };
  }

  // Esempio di utilizzo nei calcoli (da applicare in calculateDailyEarnings e simili):
  // const bonusRate = this.getHourlyRateWithBonus({
  //   baseRate: contract.hourlyRate,
  //   isOvertime: true,
  //   isNight: isNightWork(hour),
  //   isHoliday: isHolidayDay,
  //   isSunday: isSundayDay
  // });
  // earnings.overtimePay = overtimeHours * bonusRate;

  /**
   * @typedef {Object} EarningsBreakdown
   * @property {Object.<string, number>} hours - Ore suddivise per categoria (es. ordinary_day, overtime_night)
   * @property {Object.<string, number>} earnings - Guadagni suddivisi per categoria
   * @property {Object.<string, number>} allowances - Indennità (es. travel, standby)
   * @property {number} totalEarnings - Guadagno totale
   * @property {Object} details - Dettagli aggiuntivi (isHoliday, isSunday, etc.)
   */

  /**
   * Calcola la retribuzione giornaliera con un'analisi dettagliata di ogni fascia oraria e breakdown reperibilità.
   * @param {object} workEntry - L'oggetto con i dati di lavoro.
   * @param {object} settings - Le impostazioni dell'utente.
   * @returns {EarningsBreakdown} - Il dettaglio dei guadagni.
   */
  calculateEarningsBreakdown(workEntry, settings) {
    const contract = settings.contract || this.defaultContract;
    const baseRate = contract.hourlyRate;
    const travelCompensationRate = settings.travelCompensationRate || 1.0;
    const standardWorkDayHours = getWorkDayHours();
    const parsedDate = this.safeParseDate(workEntry.date);
    if (!parsedDate) {
      return {
        hours: {},
        earnings: {},
        allowances: {},
        totalEarnings: 0,
        details: { invalidDate: true },
        standbyBreakdown: {}
      };
    }
    const isHoliday = isItalianHoliday(parsedDate);
    const isSunday = parsedDate.getDay() === 0;

    // --- 1. Segmentazione: separa attività ordinarie e reperibilità ---
    // Raccogli segmenti reperibilità (interventi e viaggi associati)
    const standbySegments = [];
    if (workEntry.interventi && Array.isArray(workEntry.interventi)) {
      workEntry.interventi.forEach(iv => {
        if (iv.departure_company && iv.arrival_site) {
          standbySegments.push({ start: iv.departure_company, end: iv.arrival_site });
        }
        if (iv.work_start_1 && iv.work_end_1) {
          standbySegments.push({ start: iv.work_start_1, end: iv.work_end_1 });
        }
        if (iv.work_start_2 && iv.work_end_2) {
          standbySegments.push({ start: iv.work_start_2, end: iv.work_end_2 });
        }
        if (iv.departure_return && iv.arrival_company) {
          standbySegments.push({ start: iv.departure_return, end: iv.arrival_company });
        }
      });
    }
    // Crea una mappa di minuti coperti da reperibilità
    const standbyMinutes = new Set();
    standbySegments.forEach(seg => {
      const start = this.parseTime(seg.start);
      const duration = this.calculateTimeDifference(seg.start, seg.end);
      for (let i = 0; i < duration; i++) {
        standbyMinutes.add((start + i) % 1440);
      }
    });

    // --- 2. Segmenti ordinari (escludendo minuti di reperibilità) ---
    const ordinarySegments = [];
    if (workEntry.workStart1 && workEntry.workEnd1) {
      ordinarySegments.push({ start: workEntry.workStart1, end: workEntry.workEnd1, type: 'work' });
    }
    if (workEntry.workStart2 && workEntry.workEnd2) {
      ordinarySegments.push({ start: workEntry.workStart2, end: workEntry.workEnd2, type: 'work' });
    }
    if (workEntry.departureCompany && workEntry.arrivalSite) {
      ordinarySegments.push({ start: workEntry.departureCompany, end: workEntry.arrivalSite, type: 'travel' });
    }
    if (workEntry.departureReturn && workEntry.arrivalCompany) {
      ordinarySegments.push({ start: workEntry.departureReturn, end: workEntry.arrivalCompany, type: 'travel' });
    }

    // Mappa minuti ordinari (escludendo quelli di reperibilità)
    const ordinaryMinuteMap = {};
    for (const segment of ordinarySegments) {
      const start = this.parseTime(segment.start);
      const duration = this.calculateTimeDifference(segment.start, segment.end);
      for (let i = 0; i < duration; i++) {
        const absMinute = (start + i) % 1440;
        if (!standbyMinutes.has(absMinute)) {
          ordinaryMinuteMap[absMinute] = segment.type;
        }
      }
    }
    // Lista ordinata dei minuti ordinari effettivi
    const ordinaryMinuteList = Object.keys(ordinaryMinuteMap).map(m => ({
      type: ordinaryMinuteMap[m],
      absMinute: parseInt(m)
    })).sort((a, b) => a.absMinute - b.absMinute);

    // Conta minuti totali di lavoro e viaggio ordinari
    let totalWorkMinutes = 0;
    let totalTravelMinutes = 0;
    for (const m of ordinaryMinuteList) {
      if (m.type === 'work') totalWorkMinutes++;
      if (m.type === 'travel') totalTravelMinutes++;
    }

    // --- 3. Breakdown ore e guadagni attività ordinarie (NO reperibilità) ---
    let giornalieraWorkMinutes = 0;
    let giornalieraTravelMinutes = 0;
    let lavoroExtraMinutes = 0;
    let viaggioExtraMinutes = 0;
    let remainingWork = totalWorkMinutes;
    let remainingTravel = totalTravelMinutes;
    let assigned = 0;
    // Prima tutto il lavoro nelle 8h
    if (remainingWork > 0) {
      const toAssign = Math.min(remainingWork, standardWorkDayHours * 60);
      giornalieraWorkMinutes = toAssign;
      assigned += toAssign;
      remainingWork -= toAssign;
    }
    // Poi il viaggio nelle 8h
    if (assigned < standardWorkDayHours * 60 && remainingTravel > 0) {
      const toAssign = Math.min(remainingTravel, standardWorkDayHours * 60 - assigned);
      giornalieraTravelMinutes = toAssign;
      assigned += toAssign;
      remainingTravel -= toAssign;
    }
    lavoroExtraMinutes = remainingWork;
    viaggioExtraMinutes = remainingTravel;

    // Breakdown ore attività ordinarie
    const ordinaryHours = {
      lavoro_giornaliera: this.minutesToHours(giornalieraWorkMinutes),
      viaggio_giornaliera: this.minutesToHours(giornalieraTravelMinutes),
      lavoro_extra: this.minutesToHours(lavoroExtraMinutes),
      viaggio_extra: this.minutesToHours(viaggioExtraMinutes),
      viaggio_totale: this.minutesToHours(giornalieraTravelMinutes + viaggioExtraMinutes)
    };
    // Breakdown guadagni attività ordinarie
    const totalOrdinaryMinutes = giornalieraWorkMinutes + giornalieraTravelMinutes;
    const totalOrdinaryHours = this.minutesToHours(totalOrdinaryMinutes);
    let dailyRateAmount = 0;
    
    // Applica la retribuzione giornaliera in modo proporzionale o completata con altra modalità
    let missingHours = 0;
    let completamentoTipo = workEntry.completamentoGiornata || 'nessuno';
    
    if (totalOrdinaryMinutes > 0) {
      if (totalOrdinaryHours >= standardWorkDayHours) {
        // Se sono state lavorate 8 o più ore, paga la tariffa giornaliera completa
        dailyRateAmount = contract.dailyRate || 0;
      } else {
        // Se sono state lavorate meno di 8 ore
        missingHours = standardWorkDayHours - totalOrdinaryHours;
        
        // Verifica se c'è un tipo di completamento selezionato
        if (completamentoTipo !== 'nessuno') {
          // Se selezionato un tipo di completamento, usa il giorno completo
          dailyRateAmount = contract.dailyRate || 0;
        } else {
          // Altrimenti calcola la tariffa giornaliera come percentuale
          dailyRateAmount = (contract.dailyRate || 0) * (totalOrdinaryHours / standardWorkDayHours);
        }
      }
    }
    
    const ordinaryEarnings = {
      giornaliera: dailyRateAmount,
      viaggio_extra: viaggioExtraMinutes * (baseRate * travelCompensationRate) / 60,
      lavoro_extra: lavoroExtraMinutes * baseRate / 60
    };
    let totalOrdinaryEarnings = ordinaryEarnings.giornaliera + ordinaryEarnings.viaggio_extra + ordinaryEarnings.lavoro_extra;

    // --- 4. Breakdown reperibilità (usando funzione dedicata) ---
    const standbyBreakdown = this.calculateStandbyBreakdown ? this.calculateStandbyBreakdown(workEntry, settings) : {};
    // Nel calcolo della reperibilità è già inclusa l'indennità giornaliera
    let totalStandbyEarnings = standbyBreakdown?.totalEarnings || 0;
    // Estraiamo l'indennità per mostrarla separatamente nell'UI
    let standbyIndemnity = standbyBreakdown?.dailyIndemnity || 0;

    // --- 5. Indennità e buoni pasto ---
    const allowances = this.calculateAllowances(workEntry, settings, ordinaryHours);
    
    // --- 6. Calcolo corretto indennità di reperibilità ---
    // Verifichiamo se il giorno è di reperibilità
    const isStandbyDay = (settings.standbySettings?.standbyDays && 
                        settings.standbySettings.standbyDays[workEntry.date]?.selected) || 
                        workEntry.isStandbyDay === true || 
                        workEntry.isStandbyDay === 1;
    
    // Calcoliamo l'indennità di reperibilità se necessario
    if (isStandbyDay && !standbyIndemnity) {
        // Se standbyIndemnity è 0, significa che non è stata calcolata in calculateStandbyBreakdown
        // Quindi la calcoliamo qui
        standbyIndemnity = parseFloat(settings.standbySettings?.dailyAllowance) || 
                          parseFloat(settings.standbySettings?.dailyIndemnity) || 
                          7.50; // Valore predefinito CCNL
        
        // Aggiungiamola anche al totalStandbyEarnings
        totalStandbyEarnings += standbyIndemnity;
    }
    
    // Includiamo solo l'indennità di trasferta (NON i buoni pasto)
    let totalAllowances = (allowances.travel || 0); // Rimuoviamo allowances.meal dal totale

    // --- 7. Totale finale ---
    const totalEarnings = totalOrdinaryEarnings + totalStandbyEarnings + totalAllowances;

    // --- 7. Breakdown finale per UI ---
    return {
      ordinary: {
        hours: ordinaryHours,
        earnings: ordinaryEarnings,
        total: totalOrdinaryEarnings
      },
      standby: standbyBreakdown,
      allowances: {
        ...allowances,
        // Impostiamo sempre l'indennità di reperibilità quando il giorno è di reperibilità
        standby: standbyIndemnity
      },
      totalEarnings,
      details: {
        isHoliday,
        isSunday,
        totalWorkAndTravelHours: this.minutesToHours(totalWorkMinutes + totalTravelMinutes),
        // Aggiungiamo informazioni sul completamento giornata
        missingHours: missingHours, 
        completamentoTipo: completamentoTipo,
        isPartialDay: totalOrdinaryHours < standardWorkDayHours
      }
    };
  }

  // Check if meal allowances should be automatically activated
  shouldActivateMealAllowance(workEntry, mealType) {
    const workStart1 = this.parseTime(workEntry.workStart1);
    const workEnd1 = this.parseTime(workEntry.workEnd1);
    const workStart2 = this.parseTime(workEntry.workStart2);
    const workEnd2 = this.parseTime(workEntry.workEnd2);
    
    if (mealType === 'lunch') {
      const lunchStart = MEAL_TIMES.LUNCH_START * 60;
      const lunchEnd = MEAL_TIMES.LUNCH_END * 60;
      
      // Check if there's a break during lunch time
      if (workEnd1 && workStart2) {
        const breakStart = workEnd1;
        const breakEnd = this.parseTime(workEntry.workStart2);
        
        return (breakStart <= lunchEnd && breakEnd >= lunchStart);
      }
    } else if (mealType === 'dinner') {
      const dinnerStart = MEAL_TIMES.DINNER_START * 60;
      const dinnerEnd = MEAL_TIMES.DINNER_END * 60;
      
      // Check if work extends into dinner time
      const latestEnd = Math.max(workEnd1 || 0, workEnd2 || 0);
      return latestEnd >= dinnerStart;
    }
    
    return false;
  }

  /**
   * Calcola la retribuzione giornaliera con breakdown integrato e senza doppi conteggi tra ordinarie e reperibilità.
   * @param {object} workEntry - L'oggetto con i dati di lavoro.
   * @param {object} settings - Le impostazioni dell'utente.
   * @returns {object} - Breakdown dettagliato e coerente con CCNL.
   */
  calculateIntegratedBreakdown(workEntry, settings) {
    const contract = settings.contract || this.defaultContract;
    const baseRate = contract.hourlyRate;
    const travelCompensationRate = settings.travelCompensationRate || 1.0;
    const standardWorkDayHours = getWorkDayHours();
    const parsedDate = this.safeParseDate(workEntry.date);
    if (!parsedDate) {
      return {
        hours: { ordinarie: {}, reperibilita: {} },
        earnings: {},
        total: 0,
        details: { invalidDate: true },
        breakdownReperibilita: {}
      };
    }
    const isHoliday = isItalianHoliday(parsedDate);
    const isSunday = parsedDate.getDay() === 0;
    const standbySettings = settings.standbySettings || {};
    const standbyDays = standbySettings.standbyDays || {};
    const dailyAllowance = parseFloat(standbySettings.dailyAllowance) || 0;
    const isStandbyDay = (standbyDays && standbyDays[workEntry.date]?.selected) || workEntry.isStandbyDay === true || workEntry.isStandbyDay === 1;

    // 1. Raccogli tutti i segmenti di tempo (lavoro, viaggio, interventi reperibilità)
    const ordinarySegments = [];
    if (workEntry.workStart1 && workEntry.workEnd1) {
      ordinarySegments.push({ start: workEntry.workStart1, end: workEntry.workEnd1, type: 'work' });
    }
    if (workEntry.workStart2 && workEntry.workEnd2) {
      ordinarySegments.push({ start: workEntry.workStart2, end: workEntry.workEnd2, type: 'work' });
    }
    if (workEntry.departureCompany && workEntry.arrivalSite) {
      ordinarySegments.push({ start: workEntry.departureCompany, end: workEntry.arrivalSite, type: 'travel' });
    }
    if (workEntry.departureReturn && workEntry.arrivalCompany) {
      ordinarySegments.push({ start: workEntry.departureReturn, end: workEntry.arrivalCompany, type: 'travel' });
    }
    // Segmenti reperibilità
    const standbySegments = [];
    if (workEntry.interventi && Array.isArray(workEntry.interventi)) {
      workEntry.interventi.forEach(iv => {
        if (iv.departure_company && iv.arrival_site) {
          standbySegments.push({ start: iv.departure_company, end: iv.arrival_site, type: 'standby_travel' });
        }
        if (iv.work_start_1 && iv.work_end_1) {
          standbySegments.push({ start: iv.work_start_1, end: iv.work_end_1, type: 'standby_work' });
        }
        if (iv.work_start_2 && iv.work_end_2) {
          standbySegments.push({ start: iv.work_start_2, end: iv.work_end_2, type: 'standby_work' });
        }
        if (iv.departure_return && iv.arrival_company) {
          standbySegments.push({ start: iv.departure_return, end: iv.arrival_company, type: 'standby_travel' });
        }
      });
    }

    // 2. Costruisci una mappa dei minuti coperti da reperibilità
    const standbyMinuteMap = {};
    for (const seg of standbySegments) {
      const start = this.parseTime(seg.start);
      const duration = this.calculateTimeDifference(seg.start, seg.end);
      for (let i = 0; i < duration; i++) {
        const absMinute = (start + i) % 1440;
        standbyMinuteMap[absMinute] = seg.type;
      }
    }

    // 3. Conta minuti ordinari escludendo quelli coperti da reperibilità
    let ordinaryWorkMinutes = 0;
    let ordinaryTravelMinutes = 0;
    for (const seg of ordinarySegments) {
      const start = this.parseTime(seg.start);
      const duration = this.calculateTimeDifference(seg.start, seg.end);
      for (let i = 0; i < duration; i++) {
        const absMinute = (start + i) % 1440;
        if (!standbyMinuteMap[absMinute]) {
          if (seg.type === 'work') ordinaryWorkMinutes++;
          if (seg.type === 'travel') ordinaryTravelMinutes++;
        }
      }
    }

    // 4. Conta minuti di reperibilità (già separati per tipo)
    let standbyWorkMinutes = 0;
    let standbyTravelMinutes = 0;
    for (const m in standbyMinuteMap) {
      if (standbyMinuteMap[m] === 'standby_work') standbyWorkMinutes++;
      if (standbyMinuteMap[m] === 'standby_travel') standbyTravelMinutes++;
    }

    // 5. Breakdown ore
    const hours = {
      ordinaryWork: this.minutesToHours(ordinaryWorkMinutes),
      ordinaryTravel: this.minutesToHours(ordinaryTravelMinutes),
      standbyWork: this.minutesToHours(standbyWorkMinutes),
      standbyTravel: this.minutesToHours(standbyTravelMinutes)
    };

    // 6. Calcolo guadagni
    // --- Attività ordinarie ---
    let ordinaryEarnings = 0;
    let ordinaryTravelEarnings = 0;
    // Applica regola CCNL: prime 8h riempite prima con lavoro, poi viaggio
    let assigned = 0;
    let giornalieraWork = 0;
    let giornalieraTravel = 0;
    const maxMinutes = standardWorkDayHours * 60;
    if (ordinaryWorkMinutes > 0) {
      const toAssign = Math.min(ordinaryWorkMinutes, maxMinutes);
      giornalieraWork = toAssign;
      assigned += toAssign;
    }
    if (assigned < maxMinutes && ordinaryTravelMinutes > 0) {
      const toAssign = Math.min(ordinaryTravelMinutes, maxMinutes - assigned);
      giornalieraTravel = toAssign;
      assigned += toAssign;
    }
    const lavoroExtra = ordinaryWorkMinutes - giornalieraWork;
    const viaggioExtra = ordinaryTravelMinutes - giornalieraTravel;
    // Guadagno giornaliero CCNL
    ordinaryEarnings = (giornalieraWork + giornalieraTravel) > 0 ? (contract.dailyRate || 0) : 0;
    // Extra
    ordinaryTravelEarnings = viaggioExtra * baseRate * travelCompensationRate / 60;
    let ordinaryWorkExtraEarnings = lavoroExtra * baseRate / 60;

    // --- Reperibilità ---
    // Usa breakdown dettagliato già presente
    const standbyBreakdown = this.calculateStandbyBreakdown(workEntry, settings);

    // --- Indennità reperibilità ---
    let standbyAllowance = 0;
    if (workEntry.isStandbyDay === true || workEntry.isStandbyDay === 1 || 
        (standbyDays && standbyDays[workEntry.date]?.selected)) {
      // Debug
      console.log("Calcolo indennità reperibilità:", {
        standbyBreakdownIndemnity: standbyBreakdown.dailyIndemnity,
        settingsDailyAllowance: dailyAllowance,
        isStandbyDay: workEntry.isStandbyDay
      });
      
      standbyAllowance = standbyBreakdown.dailyIndemnity || dailyAllowance || 7.50; // Valore predefinito CCNL
    }

    // --- Totale ---
    const total = ordinaryEarnings + ordinaryTravelEarnings + ordinaryWorkExtraEarnings + (standbyBreakdown.totalEarnings || 0);

    return {
      hours: {
        ordinarie: {
          lavoro: this.minutesToHours(giornalieraWork),
          viaggio: this.minutesToHours(giornalieraTravel),
          lavoro_extra: this.minutesToHours(lavoroExtra),
          viaggio_extra: this.minutesToHours(viaggioExtra)
        },
        reperibilita: {
          lavoro: hours.standbyWork,
          viaggio: hours.standbyTravel
        }
      },
      earnings: {
        ordinarie: ordinaryEarnings,
        lavoro_extra: ordinaryWorkExtraEarnings,
        viaggio_extra: ordinaryTravelEarnings,
        reperibilita: standbyBreakdown.totalEarnings - standbyAllowance,
        indennita_reperibilita: standbyAllowance
      },
      total,
      details: {
        isStandbyDay,
        isHoliday,
        isSunday
      },
      breakdownReperibilita: standbyBreakdown
    };
  }

  /**
   * @typedef {Object} StandbyBreakdown
   * @property {number} dailyIndemnity - Indennità giornaliera per reperibilità
   * @property {Object} workHours - Ore di lavoro suddivise per fascia (es. ordinary, night, holiday)
   * @property {Object} travelHours - Ore di viaggio suddivise per fascia (es. ordinary, night, holiday)
   * @property {Object} workEarnings - Guadagni per il lavoro suddivisi per fascia
   * @property {Object} travelEarnings - Guadagni per il viaggio suddivisi per fascia
   * @property {number} totalEarnings - Guadagno totale per reperibilità (inclusa indennità)
   */

  /**
   * Calcola la suddivisione dettagliata della reperibilità per indennità, ore viaggio e ore lavoro, con fasce orarie e guadagni.
   * @param {object} workEntry - L'oggetto con i dati di lavoro.
   * @param {object} settings - Le impostazioni dell'utente.
   * @returns {StandbyBreakdown} - Il dettaglio della reperibilità.
   */
  calculateStandbyBreakdown(workEntry, settings) {
    const contract = settings.contract || this.defaultContract;
    const baseRate = contract.hourlyRate;
    const travelCompensationRate = settings.travelCompensationRate || 1.0;
    const standbySettings = settings.standbySettings || {};
    const standbyDays = standbySettings.standbyDays || {};
    const dailyAllowance = parseFloat(standbySettings.dailyAllowance) || 0;
    const isStandbyDay = (standbyDays && standbyDays[workEntry.date]?.selected) || workEntry.isStandbyDay === true || workEntry.isStandbyDay === 1;

    const parsedDate = this.safeParseDate(workEntry.date);
    if (!parsedDate) {
      return {
        dailyIndemnity: 0,
        workHours: {},
        travelHours: {},
        workEarnings: {},
        travelEarnings: {},
        totalEarnings: 0
      };
    }
    const isHoliday = isItalianHoliday(parsedDate);
    const isSunday = parsedDate.getDay() === 0;

    // Segmenti di intervento reperibilità (inclusi tutti i viaggi di partenza e ritorno)
    const segments = [];
    if (workEntry.interventi && Array.isArray(workEntry.interventi)) {
      workEntry.interventi.forEach(iv => {
        // Viaggio di partenza (azienda -> luogo intervento)
        if (iv.departure_company && iv.arrival_site) {
          segments.push({ start: iv.departure_company, end: iv.arrival_site, type: 'standby_travel' });
        }
        // Primo turno lavoro
        if (iv.work_start_1 && iv.work_end_1) {
          segments.push({ start: iv.work_start_1, end: iv.work_end_1, type: 'standby_work' });
        }
        // Secondo turno lavoro
        if (iv.work_start_2 && iv.work_end_2) {
          segments.push({ start: iv.work_start_2, end: iv.work_end_2, type: 'standby_work' });
        }
        // Viaggio di ritorno (luogo intervento -> azienda)
        if (iv.departure_return && iv.arrival_company) {
          segments.push({ start: iv.departure_return, end: iv.arrival_company, type: 'standby_travel' });
        }
      });
    }

    // Suddivisione minuti per fascia oraria
    const minuteDetails = {
      work: { ordinary: 0, night: 0, holiday: 0, night_holiday: 0 },
      travel: { ordinary: 0, night: 0, holiday: 0, night_holiday: 0 }
    };

    for (const segment of segments) {
      const startMinutes = this.parseTime(segment.start);
      const duration = this.calculateTimeDifference(segment.start, segment.end);
      for (let i = 0; i < duration; i++) {
        const currentMinute = (startMinutes + i) % 1440;
        const hour = Math.floor(currentMinute / 60);
        const night = isNightWork(hour);
        let key = 'ordinary';
        if ((isHoliday || isSunday) && night) key = 'night_holiday';
        else if (isHoliday || isSunday) key = 'holiday';
        else if (night) key = 'night';
        // Somma minuti
        if (segment.type === 'standby_work') minuteDetails.work[key]++;
        if (segment.type === 'standby_travel') minuteDetails.travel[key]++;
      }
    }

    // Conversione minuti in ore
    const hours = {
      work: {},
      travel: {}
    };
    Object.keys(minuteDetails.work).forEach(k => {
      hours.work[k] = this.minutesToHours(minuteDetails.work[k]);
      hours.travel[k] = this.minutesToHours(minuteDetails.travel[k]);
    });

    // Calcolo guadagni per fascia oraria
    const earnings = {
      work: {},
      travel: {}
    };
    // Maggiorazioni CCNL
    const ccnlRates = contract.overtimeRates || {};
    const multipliers = {
      ordinary: 1.0,
      night: ccnlRates.nightUntil22 || 1.2,
      holiday: ccnlRates.holiday || 1.3,
      night_holiday: ccnlRates.nightHoliday || 1.5
    };
    Object.keys(hours.work).forEach(k => {
      earnings.work[k] = hours.work[k] * baseRate * (multipliers[k] || 1.0);
      earnings.travel[k] = hours.travel[k] * baseRate * travelCompensationRate * (multipliers[k] || 1.0);
    });

    // Guadagno totale reperibilità (inclusa indennità)
    const isStandbyActive = (workEntry.isStandbyDay === true || workEntry.isStandbyDay === 1);
    
    const totalEarnings = Object.values(earnings.work).reduce((a, b) => a + b, 0)
      + Object.values(earnings.travel).reduce((a, b) => a + b, 0)
      + (isStandbyActive ? dailyAllowance : 0);

    // Calcolo indennità giornaliera
    const dailyIndemnity = isStandbyActive ? dailyAllowance : 0;

    return {
      dailyIndemnity, // Indennità giornaliera
      workHours: hours.work, // Ore lavoro per fascia
      travelHours: hours.travel, // Ore viaggio per fascia
      workEarnings: earnings.work, // Guadagno lavoro per fascia
      travelEarnings: earnings.travel, // Guadagno viaggio per fascia
      totalEarnings // Guadagno totale reperibilità (inclusa indennità)
    };
  }

  getRateMultiplierForCategory(category, contract) {
    const ccnlRates = contract.overtimeRates; // Assumendo che le maggiorazioni siano qui
    if (category.includes('standby')) {
        // La reperibilità segue le stesse maggiorazioni del lavoro normale/straordinario
        category = category.replace('standby_', '');
    }

    if (category === 'overtime_night_holiday') return ccnlRates.nightHolidayOvertime || 1.55; // Esempio
    if (category === 'overtime_holiday') return ccnlRates.holiday || 1.55;
    if (category === 'overtime_night') return ccnlRates.nightAfter22 || 1.50;
    if (category === 'overtime') return ccnlRates.day || 1.30;
    if (category === 'ordinary_night_holiday') return ccnlRates.nightHoliday || 1.50;
    if (category === 'ordinary_holiday') return ccnlRates.holiday || 1.40;
    if (category === 'ordinary_night') return ccnlRates.nightUntil22 || 1.20;
    
    return 1.0; // ordinary
  }

  calculateAllowances(workEntry, settings, hoursBreakdown) {
      const allowances = {
          travel: 0,
          standby: 0,
          meal: 0,
      };

      // Logica Indennità di Trasferta
      const travelSettings = settings.travelAllowance || {};
      if (travelSettings.enabled) {
          // Verifica se ci sono ore di viaggio
          const travelHours = (hoursBreakdown.viaggio_giornaliera || 0) + (hoursBreakdown.viaggio_extra || 0);
          
          // Attiva l'indennità solo se:
          // 1) ci sono ore di viaggio, OPPURE
          // 2) il flag travelAllowance è stato attivato manualmente nel form
          if (travelHours > 0 || (workEntry.travelAllowance === 1 || workEntry.travelAllowance === true)) {
              // Applica percentuale se presente (per mezza giornata)
              const percentuale = workEntry.travelAllowancePercent || 1.0;
              allowances.travel = (parseFloat(travelSettings.dailyAmount) || 0) * percentuale;
          }
      }

      // Logica Indennità di Reperibilità
      // NOTA: Questo valore viene sovrascritto nell'oggetto di ritorno 
      // usando il valore da standbyBreakdown per evitare duplicazioni
      const standbySettings = settings.standbySettings || {};
      // Corretto: considera anche il flag manuale dal form
      const isStandbyDay = (standbySettings.standbyDays && standbySettings.standbyDays[workEntry.date]?.selected) || workEntry.isStandbyDay === true || workEntry.isStandbyDay === 1;
      if (isStandbyDay) {
          // Questa parte è solo un fallback, il valore effettivo
          // viene preso da standbyBreakdown.dailyIndemnity
          allowances.standby = parseFloat(standbySettings.dailyAllowance) || 
                               parseFloat(standbySettings.dailyIndemnity) || 
                               7.50; // Valore predefinito CCNL
      }
      
      // Logica Buoni Pasto (aggiornata)
      // Gestisce correttamente i casi con valori specifici nel form (priorità) e quelli dalle impostazioni
      
      // Pranzo: valori specifici nel form hanno priorità sui valori dalle impostazioni
      if(workEntry.mealLunchCash > 0) {
        // Se c'è un valore specifico nel form, usa solo quello
        allowances.meal += workEntry.mealLunchCash;
      } else if (workEntry.mealLunchVoucher) {
        // Altrimenti usa i valori standard dalle impostazioni
        allowances.meal += settings.mealAllowances?.lunch?.voucherAmount || 0;
        allowances.meal += settings.mealAllowances?.lunch?.cashAmount || 0;
      }
      
      // Cena: stesso approccio del pranzo
      if(workEntry.mealDinnerCash > 0) {
        // Se c'è un valore specifico nel form, usa solo quello
        allowances.meal += workEntry.mealDinnerCash;
      } else if (workEntry.mealDinnerVoucher) {
        // Altrimenti usa i valori standard dalle impostazioni
        allowances.meal += settings.mealAllowances?.dinner?.voucherAmount || 0;
        allowances.meal += settings.mealAllowances?.dinner?.cashAmount || 0;
      }

      return allowances;
  }


  // Calcolo della tariffa oraria maggiorata in base al tipo di lavoro e giorno
  getHourlyRateWithBonus({
    baseRate,
    isOvertime = false,
    isNight = false,
    isHoliday = false,
    isSunday = false
  }) {
    if (isOvertime && isNight) return baseRate * 1.5; // Straordinario notturno +50%
    if (isOvertime && (isHoliday || isSunday)) return baseRate * 1.5; // Straordinario festivo/domenicale +50%
    if (isOvertime) return baseRate * 1.2; // Straordinario diurno +20%
    if (isNight && isHoliday) return baseRate * 1.6; // Lavoro ordinario notturno festivo +60%
    if (isNight) return baseRate * 1.25; // Lavoro ordinario notturno +25%
    if (isHoliday || isSunday) return baseRate * 1.3; // Lavoro ordinario festivo/domenicale +30%
    return baseRate;
  }

  // Calculate standby work earnings with night work considerations
  calculateStandbyWorkEarnings(start1, end1, start2, end2, contract) {
    let totalEarnings = 0;
    
    const shifts = [
      { start: start1, end: end1 },
      { start: start2, end: end2 }
    ];
    
    shifts.forEach(shift => {
      if (!shift.start || !shift.end) return;
      
      const startHour = parseInt(shift.start.split(':')[0]);
      const endHour = parseInt(shift.end.split(':')[0]);
      const shiftMinutes = this.calculateTimeDifference(shift.start, shift.end);
      const shiftHours = this.minutesToHours(shiftMinutes);
      
      // Simplified calculation - could be more sophisticated to handle mixed rates within shift
      let rate = contract.hourlyRate;
      
      if (endHour > 22 || endHour < 6) {
        rate = contract.hourlyRate * contract.overtimeRates.nightAfter22;
      } else if (startHour >= 22 || endHour >= 22) {
        rate = contract.hourlyRate * contract.overtimeRates.nightUntil22;
      } else {
        rate = contract.hourlyRate * contract.overtimeRates.day;
      }
      
      totalEarnings += shiftHours * rate;
    });
    
    return totalEarnings;
  }

  // Calculate monthly summary
  calculateMonthlySummary(workEntries, settings) {
    const summary = {
      totalHours: 0,
      workHours: 0,
      travelHours: 0,
      overtimeHours: 0,
      standbyWorkHours: 0,
      standbyTravelHours: 0,
      regularDays: 0,
      standbyDays: 0,
      totalEarnings: 0,
      regularPay: 0,
      overtimePay: 0,
      travelPay: 0,
      standbyPay: 0,
      allowances: 0,
      mealAllowances: 0,
      dailyBreakdown: []
    };
    
    workEntries.forEach(entry => {
      const dailyEarnings = this.calculateDailyEarnings(entry, settings);
      const workHours = this.calculateWorkHours(entry);
      const travelHours = this.calculateTravelHours(entry);
      const standbyWorkHours = this.calculateStandbyWorkHours(entry);
      const standbyTravelHours = this.calculateStandbyTravelHours(entry);
      
      summary.totalHours += workHours + travelHours + standbyWorkHours + standbyTravelHours;
      summary.workHours += workHours;
      summary.travelHours += travelHours;
      summary.overtimeHours += dailyEarnings.breakdown.overtimeHours;
      summary.standbyWorkHours += standbyWorkHours;
      summary.standbyTravelHours += standbyTravelHours;
      
      if (entry.isStandbyDay) {
        summary.standbyDays++;
      } else {
        summary.regularDays++;
      }
      
      summary.totalEarnings += dailyEarnings.total;
      summary.regularPay += dailyEarnings.regularPay;
      summary.overtimePay += dailyEarnings.overtimePay;
      summary.travelPay += dailyEarnings.travelPay;
      summary.standbyPay += dailyEarnings.standbyWorkPay + dailyEarnings.standbyTravelPay;
      summary.allowances += dailyEarnings.travelAllowance + dailyEarnings.standbyAllowance;
      summary.mealAllowances += dailyEarnings.mealAllowances;
      
      summary.dailyBreakdown.push({
        date: entry.date,
        workHours,
        travelHours,
        standbyWorkHours,
        standbyTravelHours,
        earnings: dailyEarnings.total,
        isStandbyDay: entry.isStandbyDay
      });
    });
    
    return summary;
  }

  /**
   * Safe date parsing utility
   */
  safeParseDate(dateValue) {
    if (!dateValue) return null;
    const d = new Date(dateValue);
    return isNaN(d.getTime()) ? null : d;
  }
}

// --- FINE CLASSE ---

export default new CalculationService();
